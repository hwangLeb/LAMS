-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 02, 2023 at 08:25 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `attendancemanagement`
--

-- --------------------------------------------------------

--
-- Table structure for table `class_page_database`
--

CREATE TABLE `class_page_database` (
  `id` int(11) NOT NULL,
  `student_number` varchar(50) NOT NULL,
  `student_name` varchar(50) NOT NULL,
  `subject` varchar(50) NOT NULL,
  `section` varchar(50) NOT NULL,
  `start_time` varchar(50) NOT NULL,
  `end_time` varchar(50) NOT NULL,
  `days` varchar(50) NOT NULL,
  `room` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `class_page_database`
--

INSERT INTO `class_page_database` (`id`, `student_number`, `student_name`, `subject`, `section`, `start_time`, `end_time`, `days`, `room`) VALUES
(1, '8210414', 'fiend, shadow', 'System Analysis and Design', 'BSIT 2.1', '6:00', '11:00', 'monday', '409'),
(2, '8210418', 'aviso, carlo', 'Object Oriented Programming', 'BSIT 2.1', '7:00', '12:00', 'Monday/Tuesday', '409'),
(3, '8210418', 'aviso, carlo', 'Computer Programming 2', 'BSIT 1.1', '6:00', '10:00', 'Friday', '409'),
(4, '8210418', 'aviso, carlo', 'System Analysis and Design', 'BSIT 2.1', '6:00', '13:00', 'Wednesday', '309');

-- --------------------------------------------------------

--
-- Table structure for table `professor_account_database`
--

CREATE TABLE `professor_account_database` (
  `id` int(11) NOT NULL,
  `account_id` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `user_type` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `professor_account_database`
--

INSERT INTO `professor_account_database` (`id`, `account_id`, `last_name`, `first_name`, `email`, `phone`, `user_type`, `password`) VALUES
(1, 'professor001', 'pedro', 'penduko', 'pedropenduko@gmail.com', '09279109751', 'Admin', '123456');

-- --------------------------------------------------------

--
-- Table structure for table `student_account_database`
--

CREATE TABLE `student_account_database` (
  `id` int(11) NOT NULL,
  `student_number` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `user_type` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student_account_database`
--

INSERT INTO `student_account_database` (`id`, `student_number`, `last_name`, `first_name`, `email`, `phone`, `gender`, `user_type`, `password`) VALUES
(1, '8210418', 'aviso', 'carlo', 'c.aviso@gmail.com', '09279109694', 'Male', 'Student', '12345'),
(2, '8210417', 'Dela Cruz', 'Juana', 'J.Dealacruz@gmail.com', '09279109554', 'Male', 'Student', '012345'),
(3, '8210416', 'Santos', 'Charo', 'c.santos@gmail.com', '09279109691', 'Female', 'Student', '0123'),
(4, '8210415', 'Reyes', 'Fred', 'f.reyes@gmail.com', '092791092', 'Male', 'Student', '1234'),
(5, '8210414', 'fiend', 'shadow', 's.fiend@gmail.com', '0927910960', 'Male', 'Student', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `student_attendance_page`
--

CREATE TABLE `student_attendance_page` (
  `id` int(11) DEFAULT NULL,
  `student_number` varchar(50) NOT NULL,
  `student_name` varchar(50) NOT NULL,
  `subject` varchar(50) NOT NULL,
  `section` varchar(50) NOT NULL,
  `room` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `subject_page_database`
--

CREATE TABLE `subject_page_database` (
  `id` int(11) NOT NULL,
  `student_number` varchar(50) NOT NULL,
  `student_name` varchar(50) NOT NULL,
  `year_level` varchar(50) NOT NULL,
  `semester` varchar(50) NOT NULL,
  `type_of_student` varchar(50) NOT NULL,
  `subject1` varchar(50) NOT NULL,
  `subject2` varchar(50) NOT NULL,
  `subject3` varchar(50) NOT NULL,
  `subject4` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subject_page_database`
--

INSERT INTO `subject_page_database` (`id`, `student_number`, `student_name`, `year_level`, `semester`, `type_of_student`, `subject1`, `subject2`, `subject3`, `subject4`) VALUES
(2, '8210414', 'fiend, shadow', 'Second Year', 'Second Semester', 'Regular', 'System Analysis and Design', 'Information Assurance and Security 1', 'Object Oriented Programming', 'Web Development'),
(3, '8210418', 'aviso, carlo', 'Second Year', 'Second Semester', 'Irregular', 'Computer Programming 2', 'Multimedia', 'System Analysis and Design', 'Object Oriented Programming');

-- --------------------------------------------------------

--
-- Table structure for table `view_attendance_database`
--

CREATE TABLE `view_attendance_database` (
  `student_number` varchar(50) NOT NULL,
  `student_name` varchar(50) NOT NULL,
  `subject` varchar(50) NOT NULL,
  `section` varchar(50) NOT NULL,
  `room` varchar(50) NOT NULL,
  `time_in` varchar(50) NOT NULL,
  `date` varchar(50) NOT NULL,
  `time_out` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `view_attendance_database`
--

INSERT INTO `view_attendance_database` (`student_number`, `student_name`, `subject`, `section`, `room`, `time_in`, `date`, `time_out`) VALUES
('8210418', 'aviso, carlo', 'Object Oriented Programming', 'BSIT 2.1', '409', '10:52:44 AM', 'Jun-02-2023', '0'),
('8210418', 'aviso, carlo', 'Computer Programming 2', 'BSIT 1.1', '409', '11:00:55 AM', 'Jun-02-2023', '0'),
('8210418', 'aviso, carlo', 'System Analysis and Design', 'BSIT 2.1', '309', '11:25:30 AM', 'Jun-02-2023', '0'),
('8210418', 'aviso, carlo', 'Object Oriented Programming', 'BSIT 2.1', '409', '11:26:23 AM', 'Jun-02-2023', '0');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `class_page_database`
--
ALTER TABLE `class_page_database`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `professor_account_database`
--
ALTER TABLE `professor_account_database`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student_account_database`
--
ALTER TABLE `student_account_database`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subject_page_database`
--
ALTER TABLE `subject_page_database`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `class_page_database`
--
ALTER TABLE `class_page_database`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `professor_account_database`
--
ALTER TABLE `professor_account_database`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `student_account_database`
--
ALTER TABLE `student_account_database`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `subject_page_database`
--
ALTER TABLE `subject_page_database`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
