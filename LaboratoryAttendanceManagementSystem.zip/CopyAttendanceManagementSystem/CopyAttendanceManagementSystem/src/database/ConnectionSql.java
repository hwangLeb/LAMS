
package database;
import java.sql.Connection;
import java.sql.DriverManager;

public class ConnectionSql {
    
    private static Connection con;
    
    public static Connection getConnection() {
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/attendancemanagement", "root", "");
        }catch(Exception ex) {
            System.out.println("" + ex);
        }
        return con;
    }
    
    
}
