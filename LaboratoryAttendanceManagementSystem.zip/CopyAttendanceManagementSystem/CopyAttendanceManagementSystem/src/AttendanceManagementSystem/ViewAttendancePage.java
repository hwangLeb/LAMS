/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AttendanceManagementSystem;

import database.ConnectionSql;
import java.sql.Connection;
import java.sql.PreparedStatement;
import database.ConnectionSql;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

public class ViewAttendancePage {

    Connection con = ConnectionSql.getConnection();
    PreparedStatement ps;
    private DefaultTableModel model;
     public void filterAttendance(String query){
      TableRowSorter<DefaultTableModel> tableRow = new TableRowSorter<DefaultTableModel>(model);
     tableRow.setRowFilter(RowFilter.regexFilter(query));
      }
     
     public int getMax() {
        int id = 0;
        Statement st;
        try {
            st = con.createStatement();
            ResultSet rs = st.executeQuery("select max(id) from view_attendance_database");
            while (rs.next()) {
                id = rs.getInt(1);
            }
        } catch (SQLException ex) {
            Logger.getLogger(ViewAttendancePage.class.getName()).log(Level.SEVERE, null, ex);
        }
        return id + 1;
    }
    public void insert(int id, String studentNumber, String studentName, String subject, String section, String room, String timeIn, String date, String timeOut) {

        PreparedStatement ps;
        String query = "INSERT INTO view_attendance_database VALUES (?,?,?,?,?,?,?,?,?)";

        try {
            ps = ConnectionSql.getConnection().prepareStatement(query);
            ps.setInt(1, id);
            ps.setString(2, studentNumber);
            ps.setString(3, studentName);
            ps.setString(4, subject);
            ps.setString(5, section);
            ps.setString(6, room);
            ps.setString(7, timeIn);
            ps.setString(8, date);
            ps.setString(9, timeOut);

            if (ps.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(null, "Attendace added successfully");
            }
        } catch (SQLException ex) {
            Logger.getLogger(ConnectionSql.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public void getStudentAttendanceDatabase(JTable table, String searchValue) { //get user_database paste to studentTable
        String query = "SELECT * FROM view_attendance_database WHERE concat (student_number,student_name) like ? order by student_number asc";
        try {
            ps = con.prepareStatement(query);
            ps.setString(1, "%" + searchValue + "%");
            ResultSet rs = ps.executeQuery();
            DefaultTableModel model = (DefaultTableModel) table.getModel();
            Object[] row;
            while (rs.next()) {
                row = new Object[9];
                row[0] = rs.getString(2);
                row[1] = rs.getString(3);
                row[2] = rs.getString(4);
                row[3] = rs.getString(5);
                row[4] = rs.getString(6);
                row[5] = rs.getString(7);
                row[6] = rs.getString(8);
                row[7] = rs.getString(9);
                model.addRow(row);
            }
        } catch (SQLException ex) {
            Logger.getLogger(ViewAttendancePage.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

     public void delete(int id) {
        int choice = JOptionPane.showConfirmDialog(null, "Are you sure you want to delete", "Attendance history of student Delete", JOptionPane.OK_CANCEL_OPTION, 0);
        if (choice == JOptionPane.OK_OPTION) {
            try {
                ps = con.prepareStatement("DELETE FROM view_attendance_database WHERE id=?");
                ps.setInt(1, id);
                if (ps.executeUpdate() > 0) {
                    JOptionPane.showMessageDialog(null, "Class subject data deleted");

                }
            } catch (SQLException ex) {
                Logger.getLogger(ViewAttendancePage.class
                        .getName()).log(Level.SEVERE, null, ex);
            }

        }
    }
   // void insert(String studentNumber, String studentName, String subject, String section, String room, String date, String timeOut) {
       // throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    //}

    //void getjButton6() {
       // throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    //}

    //void getjButton1() {
        //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
   // }

}
