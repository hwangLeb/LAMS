package AttendanceManagementSystem;

import java.sql.Connection;
import java.sql.PreparedStatement;
import database.ConnectionSql;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class StudentAccountRegistration {

    Connection con = ConnectionSql.getConnection();
    PreparedStatement ps;
    
    public boolean isStudentEmailExist(String email) {
        try {
            ps = con.prepareStatement("SELECT * FROM student_account_database WHERE email=?");
            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return true;
            }
        } catch (SQLException ex) {
            Logger.getLogger(StudentAccountRegistration.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
     public boolean isStudentPhoneExist(String phone) {
        try {
            ps = con.prepareStatement("SELECT * FROM student_account_database WHERE phone=?");
            ps.setString(1, phone);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return true;
            }
        } catch (SQLException ex) {
            Logger.getLogger(StudentAccountRegistration.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
     
     public boolean isStudentIdExist(int id) {
        try {
            ps = con.prepareStatement("SELECT * FROM student_account_database WHERE id=?");
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return true;
            }
        } catch (SQLException ex) {
            Logger.getLogger(StudentAccountRegistration.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
     
      public int getMax() {
        int id = 0;
        Statement st;
        try {
            st = con.createStatement();
            ResultSet rs = st.executeQuery("select max(id) from student_account_database");
            while (rs.next()) {
                id = rs.getInt(1);
            }
        } catch (SQLException ex) {
            Logger.getLogger(StudentAccountRegistration.class.getName()).log(Level.SEVERE, null, ex);
        }
        return id + 1;
    }
      
      public void insert(int id, String studentNumber, String lastName, String firstName, String email, String phone, String gender, String userType, String password) {

        PreparedStatement ps;
        String query = "INSERT INTO student_account_database VALUES (?,?,?,?,?,?,?,?,?)";

        try {
            ps = ConnectionSql.getConnection().prepareStatement(query);
            ps.setInt(1, id);
            ps.setString(2, studentNumber);
            ps.setString(3, lastName);
            ps.setString(4, firstName);
            ps.setString(5, email);
            ps.setString(6, phone);
            ps.setString(7, gender);
            ps.setString(8, userType);
            ps.setString(9, password);

            if (ps.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(null, "Student added successfully");
            }
        } catch (SQLException ex) {
            Logger.getLogger(ConnectionSql.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
      
      public void update(int id, String studentNumber, String lastName, String firstName, String email, String phone, String gender, String userType, String password) {

        PreparedStatement ps;
        String query = "UPDATE student_account_database SET student_number=?, last_name=?, first_name=?, email=?, phone=?, gender=?, user_type=?, password=? WHERE id   =?";

        try {

            ps = ConnectionSql.getConnection().prepareStatement(query);
            
            ps.setString(1, studentNumber);
            ps.setString(2, lastName);
            ps.setString(3, firstName);
            ps.setString(4, email);
            ps.setString(5, phone);
            ps.setString(6, gender);
            ps.setString(7, userType);
            ps.setString(8, password);
            ps.setInt(9, id);

            if (ps.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(null, "Student account update successfully");
            }
        } catch (SQLException ex) {
            Logger.getLogger(ConnectionSql.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
      
      public void delete(int id) {
        int choice = JOptionPane.showConfirmDialog(null, "Are you sure you want to delete", "Student Delete", JOptionPane.OK_CANCEL_OPTION, 0);
        if (choice == JOptionPane.OK_OPTION) {
            try {
                ps = con.prepareStatement("DELETE FROM student_account_database WHERE id=?");
                ps.setInt(1, id);
                if (ps.executeUpdate() > 0) {
                    JOptionPane.showMessageDialog(null, "Student data deleted");
                }
            } catch (SQLException ex) {
                Logger.getLogger(StudentAccountRegistration.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
    }
      
      public void getStudentAccountDatabase(JTable table, String searchValue) { //get user_database paste to studentTable
        String query = "SELECT * FROM student_account_database WHERE concat (id,student_number,email,phone) like ? order by id asc";
        try {
            ps = con.prepareStatement(query);
            ps.setString(1, "%" + searchValue + "%");
            ResultSet rs = ps.executeQuery();
            DefaultTableModel model = (DefaultTableModel) table.getModel();
            Object[] row;
            while (rs.next()) {
                row = new Object[9];
                row[0] = rs.getInt(1);
                row[1] = rs.getString(2);
                row[2] = rs.getString(3);
                row[3] = rs.getString(4);
                row[4] = rs.getString(5);
                row[5] = rs.getString(6);
                row[6] = rs.getString(7);
                row[7] = rs.getString(8);
                row[8] = rs.getString(9);
                model.addRow(row);
            }
        } catch (SQLException ex) {
            Logger.getLogger(StudentAccountRegistration.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
