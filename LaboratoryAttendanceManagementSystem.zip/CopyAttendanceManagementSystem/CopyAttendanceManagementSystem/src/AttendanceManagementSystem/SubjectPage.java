/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AttendanceManagementSystem;

import java.sql.Connection;
import java.sql.PreparedStatement;
import database.ConnectionSql;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

     

public class SubjectPage {
    Connection con = ConnectionSql.getConnection();
    PreparedStatement ps;
    
    
    public int getMax() {
        int id = 0;
        Statement st;
        try {
            st = con.createStatement();
            ResultSet rs = st.executeQuery("select max(id) from subject_page_database");
            while (rs.next()) {
                id = rs.getInt(1);
            }
        } catch (SQLException ex) {
            Logger.getLogger(SubjectPage.class.getName()).log(Level.SEVERE, null, ex);
        }
        return id + 1;
    }
    
     public boolean isStudentIdExist(int id) {
        try {
            ps = con.prepareStatement("SELECT * FROM subject_page_database WHERE id=?");
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return true;
            }
        } catch (SQLException ex) {
            Logger.getLogger(SubjectPage.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
    public void getSubjectSearchBtn() {
        try {
             ps = con.prepareStatement("SELECT student_number,CONCAT(last_name, ', ',first_name) AS student_name  from student_account_database where student_number=?");

            String accountID = (AdminPage.subjectPageSearchField.getText());
            ps.setString(1, accountID);

            ResultSet rs = ps.executeQuery();
            if (rs.next() == false) {
                JOptionPane.showMessageDialog(null, "Student number doesn't exists");
                AdminPage.subjectPageStudentNumber.setText("");
                AdminPage.subjectPageStudentName.setText("");
                
                
            } else {
                AdminPage.subjectPageStudentNumber.setText(rs.getString("student_number"));
                AdminPage.subjectPageStudentName.setText(rs.getString("student_name"));
                

            }
        } catch (SQLException ex) {
            Logger.getLogger(SubjectPage.class.getName()).log(Level.SEVERE, null, ex);
        }
    
}
    public void insert(int id, int studentNumber, String studentName, String yearLevel, String semester, String typeOfStudent,
            String subject1, String subject2, String subject3, String subject4) {

        PreparedStatement ps;
        String query = "INSERT INTO subject_page_database VALUES (?,?,?,?,?,?,?,?,?,?)";

        try {
            ps = ConnectionSql.getConnection().prepareStatement(query);
            ps.setInt(1, id);
            ps.setInt(2, studentNumber);
            ps.setString(3, studentName);
            ps.setString(4, yearLevel);
            ps.setString(5, semester);
            ps.setString(6, typeOfStudent);
            ps.setString(7, subject1);
            ps.setString(8, subject2);
            ps.setString(9, subject3);
            ps.setString(10, subject4);

            if (ps.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(null, "Subject added successfully");
            }
        } catch (SQLException ex) {
            Logger.getLogger(SubjectPage.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
    
    public void update(int id, String studentNumber, String studentName, String yearLevel, String semester, String typeOfStudent,
            String subject1, String subject2, String subject3, String subject4) {

        PreparedStatement ps;
        String query = "UPDATE subject_page_database SET student_number=?, student_name=?, year_level=?, semester=?, type_of_student=?, subject1=?, subject2=?, "
                + "subject3=?, subject4=?  WHERE id=?";

        try {

            ps = ConnectionSql.getConnection().prepareStatement(query);
            
            
            ps.setString(1, studentNumber);
            ps.setString(2, studentName);
            ps.setString(3, yearLevel);
            ps.setString(4, semester);
            ps.setString(5, typeOfStudent);
            ps.setString(6, subject1);
            ps.setString(7, subject2);
            ps.setString(8, subject3);
            ps.setString(9, subject4);
            ps.setInt(10, id);

            if (ps.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(null, "Student account update successfully");
            }
        } catch (SQLException ex) {
            Logger.getLogger(ConnectionSql.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void delete(int id) {
        int choice = JOptionPane.showConfirmDialog(null, "Are you sure you want to delete", "Student subject Delete", JOptionPane.OK_CANCEL_OPTION, 0);
        if (choice == JOptionPane.OK_OPTION) {
            try {
                ps = con.prepareStatement("DELETE FROM subject_page_database WHERE id=?");
                ps.setInt(1, id);
                if (ps.executeUpdate() > 0) {
                    JOptionPane.showMessageDialog(null, "Student subject data deleted");
                }
            } catch (SQLException ex) {
                Logger.getLogger(SubjectPage.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
    }
    
      public boolean isSubjectExist(int studentNumber, String subjectNo, String subject) {
        String query = "SELECT * FROM subject_page_database WHERE student_number=? and " + subjectNo + " =?";
        try {
            ps = con.prepareStatement(query);
            ps.setInt(1, studentNumber);
            ps.setString(2, subject);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return true;
            }
        } catch (SQLException ex) {
            Logger.getLogger(SubjectPage.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
      
       public boolean isSemesterExist(int studentNumber, String semester) {
        String query = "SELECT * FROM subject_page_database WHERE student_number=? and id=?";
        try {
            ps = con.prepareStatement(query);
            ps.setInt(1, studentNumber);
            ps.setString(2, semester);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return true;
            }
        } catch (SQLException ex) {
            Logger.getLogger(SubjectPage.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
        public void getSubjectDatabase(JTable table, String searchValue) {
        String query = "SELECT * FROM subject_page_database WHERE concat (id,student_number,student_name) like ? order by id asc";
        try {
            ps = con.prepareStatement(query);
            ps.setString(1, "%" + searchValue + "%");
            ResultSet rs = ps.executeQuery();
            DefaultTableModel model = (DefaultTableModel) table.getModel();
            Object[] row;
            while (rs.next()) {
                row = new Object[10];
                row[0] = rs.getInt(1);
                row[1] = rs.getString(2);
                row[2] = rs.getString(3);
                row[3] = rs.getString(4);
                row[4] = rs.getString(5);
                row[5] = rs.getString(6);
                row[6] = rs.getString(7);
                row[7] = rs.getString(8);
                row[8] = rs.getString(9);
                row[9] = rs.getString(10);
                model.addRow(row);
            }
        } catch (SQLException ex) {
            Logger.getLogger(SubjectPage.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
        
}