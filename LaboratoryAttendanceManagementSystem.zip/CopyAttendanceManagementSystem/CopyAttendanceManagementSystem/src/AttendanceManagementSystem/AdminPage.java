/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package AttendanceManagementSystem;

import database.ConnectionSql;
import java.awt.Color;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class AdminPage extends javax.swing.JFrame {

    ProfessorAccountRegistration professoraccountregistration = new ProfessorAccountRegistration();
    StudentAccountRegistration studentaccountregistration = new StudentAccountRegistration();
    SubjectPage subjectpage = new SubjectPage();
    ClassPage classpage = new ClassPage();
    ViewAttendancePage viewAttendance = new ViewAttendancePage();
   

    private DefaultTableModel model;
    private int rowIndex;

    public AdminPage() {
        initComponents();
        init();

    }

    public void init() {
        tableViewProfessorPage();
        tableViewStudentPage();
        tableViewSubjectPage();
        tableViewClassPage();
        tableViewAttendancePage();

        professorPageID.setText(String.valueOf(professoraccountregistration.getMax()));
        studentPageID.setText(String.valueOf(studentaccountregistration.getMax()));
        subjectPageID.setText(String.valueOf(subjectpage.getMax()));
        classPageID.setText(String.valueOf(classpage.getMax()));
        //subjectTabID.setText(String.valueOf(subjectpage.getMax()));
    }

    public boolean isProfessorPageFieldEmpty() {
        if (professorPageAccountID.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill account id !");
            return false;
        }

        if (professorPageLastName.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill last name");
            return false;
        }
        if (professorPageFirstName.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill first name ");
            return false;
        }
        if (professorPageEmail.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill email");
            return false;
        }
        if (!professorPageEmail.getText().matches("^.+@.+\\..+$")) {
            JOptionPane.showMessageDialog(this, "Invalid email address");
            return false;
        }
        if (professorPagePhone.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill email");
            return false;
        }
        if (professorPagePhone.getText().length() >= 12) {
            JOptionPane.showMessageDialog(this, "Phone number is too long!");
            return false;
        }

        if (professorPagePassword.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill pasword !");
            return false;
        }

        return true;

    }

    public boolean checkProfessorPage() {
        String newEmail = professorPageEmail.getText();
        String newPhone = professorPagePhone.getText();
        String oldEmail = model.getValueAt(rowIndex, 4).toString();
        String oldPhone = model.getValueAt(rowIndex, 5).toString();

        if (newEmail.equals(oldEmail) && newPhone.equals(oldPhone)) {
            return false;
        } else {
            if (!newEmail.equals(oldEmail)) {
                boolean emailExist = professoraccountregistration.isProfessorEmailExist(newEmail);
                if (emailExist) {
                    JOptionPane.showMessageDialog(this, "Sorry, email already exists");
                }
                return emailExist;
            }
        }
        if (!newPhone.equals(oldPhone)) {
            boolean emailExist = professoraccountregistration.isProfessorPhoneExist(newPhone);
            if (emailExist) {
                JOptionPane.showMessageDialog(this, "Sorry, phone number already exists");
            }
            return emailExist;
        }
        return false;
    }

    private void tableViewProfessorPage() {
        professoraccountregistration.getProfessorAccountDatabase(professorPageTable, "");
        model = (DefaultTableModel) professorPageTable.getModel();
    }

    private void professorPageClearField() {
        professorPageID.setText(String.valueOf(professoraccountregistration.getMax()));
        professorPageAccountID.setText(null);
        professorPageLastName.setText(null);
        professorPageFirstName.setText(null);
        professorPageEmail.setText(null);
        professorPagePhone.setText(null);
        professorPageUserType.setSelectedIndex(0);
        professorPagePassword.setText(null);
        professorPageTable.clearSelection();
    }

    public boolean isStudentPageFieldEmpty() {
        if (studentPageStudentNumber.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill student number");
            return false;
        }

        if (studentPageLastName.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill last name");
            return false;
        }
        if (studentPageFirstName.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill first name ");
            return false;
        }
        if (studentPageEmail.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill email");
            return false;
        }
        if (!studentPageEmail.getText().matches("^.+@.+\\..+$")) {
            JOptionPane.showMessageDialog(this, "Invalid email address");
            return false;
        }
        if (studentPagePhone.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill email");
            return false;
        }
        if (studentPagePhone.getText().length() >= 12) {
            JOptionPane.showMessageDialog(this, "Phone number is too long!");
            return false;
        }

        if (studentPagePassword.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill pasword !");
            return false;
        }

        return true;
    }

    public boolean checkStudentPage() {
        String newEmail = studentPageEmail.getText();
        String newPhone = studentPagePhone.getText();
        String oldEmail = model.getValueAt(rowIndex, 5).toString();
        String oldPhone = model.getValueAt(rowIndex, 6).toString();

        if (newEmail.equals(oldEmail) && newPhone.equals(oldPhone)) {
            return false;
        } else {
            if (!newEmail.equals(oldEmail)) {
                boolean emailExist = studentaccountregistration.isStudentEmailExist(newEmail);
                if (emailExist) {
                    JOptionPane.showMessageDialog(this, "Sorry, email already exists");
                }
                return emailExist;
            }
        }
        if (!newPhone.equals(oldPhone)) {
            boolean emailExist = studentaccountregistration.isStudentPhoneExist(newPhone);
            if (emailExist) {
                JOptionPane.showMessageDialog(this, "Sorry, phone number already exists");
            }
            return emailExist;
        }
        return false;
    }

    private void tableViewStudentPage() {
        studentaccountregistration.getStudentAccountDatabase(studentPageTable, "");
        model = (DefaultTableModel) studentPageTable.getModel();

    }

    private void studentPageClearField() {
        studentPageID.setText(String.valueOf(studentaccountregistration.getMax()));
        studentPageStudentNumber.setText(null);
        studentPageLastName.setText(null);
        studentPageFirstName.setText(null);
        studentPageEmail.setText(null);
        studentPagePhone.setText(null);
        studentPageGender.setSelectedIndex(-1);
        studentPageUserType.setSelectedIndex(-1);
        studentPagePassword.setText(null);
        studentPageTable.clearSelection();
    }

    private void tableViewSubjectPage() {
        subjectpage.getSubjectDatabase(subjectPageTable, "");
        model = (DefaultTableModel) subjectPageTable.getModel();
    }

    private void subjectPageClearField() {
        subjectPageID.setText(String.valueOf(subjectpage.getMax()));
        subjectPageStudentNumber.setText(null);
        subjectPageStudentName.setText(null);
        subjectPageYearLevel.setSelectedIndex(0);
        subjectPageSemester.setSelectedIndex(0);
        subjectPageTypeOfStudent.setSelectedIndex(0);
        subjectPageSubject1.setSelectedIndex(0);
        subjectPageSubject2.setSelectedIndex(0);
        subjectPageSubject3.setSelectedIndex(0);
        subjectPageSubject4.setSelectedIndex(0);
        subjectPageTable.clearSelection();
    }

    public boolean isSubjectPageFieldEmpty() {
        if (subjectPageStudentNumber.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter student number");
            return false;
        }
        if (subjectPageStudentName.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Error!");
            return false;
        }

        return true;
    }

    private void tableViewClassPage() {
        classpage.getClassDatabase(classPageTable, "");
        model = (DefaultTableModel) classPageTable.getModel();
    }

    private void classPageClearField() {
        classPageID.setText(String.valueOf(subjectpage.getMax()));
        classPageStudentNumber.setText(null);
        classPageStudentName.setText(null);
        classPageSubject.setSelectedItem(0);
        classPageSection.setSelectedItem(0);
        classPageStartTime.setSelectedIndex(-1);
        classPageEndTime.setSelectedIndex(-1);
        classPageDays.setText(null);
        classPageRoom.setText(null);
        classPageTable.clearSelection();
    }

    public boolean isClassPageFieldEmpty() {
        if (classPageStudentNumber.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter student number");
            return false;
        }
        if (classPageStudentName.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Error!");
            return false;
        }

        if (classPageDays.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter schedule date");
            return false;
        }
        if (classPageRoom.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter room location");
            return false;
        }
        return true;
    }

    private void tableViewAttendancePage() {
        viewAttendance.getStudentAttendanceDatabase(viewAttendancePageTable, "");
        model = (DefaultTableModel) viewAttendancePageTable.getModel();

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        attendancePanel = new javax.swing.JPanel();
        jPanel14 = new javax.swing.JPanel();
        jScrollPane5 = new javax.swing.JScrollPane();
        viewAttendancePageTable = new javax.swing.JTable();
        viewAttendancePageSearchField = new javax.swing.JTextField();
        jButton6 = new javax.swing.JButton();
        ClassPanel = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jLabel23 = new javax.swing.JLabel();
        classPageSearchField = new javax.swing.JTextField();
        classPageSearchbtn = new javax.swing.JButton();
        jPanel12 = new javax.swing.JPanel();
        jLabel24 = new javax.swing.JLabel();
        classPageID = new javax.swing.JTextField();
        jLabel25 = new javax.swing.JLabel();
        classPageStudentNumber = new javax.swing.JTextField();
        jLabel26 = new javax.swing.JLabel();
        classPageStudentName = new javax.swing.JTextField();
        jLabel27 = new javax.swing.JLabel();
        classPageSubject = new javax.swing.JComboBox<>();
        jLabel38 = new javax.swing.JLabel();
        classPageStartTime = new javax.swing.JComboBox<>();
        jLabel39 = new javax.swing.JLabel();
        classPageEndTime = new javax.swing.JComboBox<>();
        jLabel40 = new javax.swing.JLabel();
        classPageDays = new javax.swing.JTextField();
        jLabel41 = new javax.swing.JLabel();
        classPageRoom = new javax.swing.JTextField();
        jLabel42 = new javax.swing.JLabel();
        classPageSection = new javax.swing.JComboBox<>();
        jPanel15 = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        classPageTable = new javax.swing.JTable();
        classPageEditBtn = new javax.swing.JButton();
        classPageClearBtn = new javax.swing.JButton();
        classPageDeleteBtn = new javax.swing.JButton();
        classPageSaveBtn = new javax.swing.JButton();
        SubjectPanel = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        subjectPageSearchField = new javax.swing.JTextField();
        subjectPageSearchBtn = new javax.swing.JButton();
        jPanel11 = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        subjectPageStudentNumber = new javax.swing.JTextField();
        jLabel19 = new javax.swing.JLabel();
        subjectPageID = new javax.swing.JTextField();
        jLabel20 = new javax.swing.JLabel();
        subjectPageStudentName = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        subjectPageSemester = new javax.swing.JComboBox<>();
        subjectPageYearLevel = new javax.swing.JComboBox<>();
        jLabel16 = new javax.swing.JLabel();
        subjectPageTypeOfStudent = new javax.swing.JComboBox<>();
        jLabel17 = new javax.swing.JLabel();
        subjectPageSubject1 = new javax.swing.JComboBox<>();
        jLabel18 = new javax.swing.JLabel();
        subjectPageSubject2 = new javax.swing.JComboBox<>();
        jLabel21 = new javax.swing.JLabel();
        subjectPageSubject3 = new javax.swing.JComboBox<>();
        jLabel22 = new javax.swing.JLabel();
        subjectPageSubject4 = new javax.swing.JComboBox<>();
        subjectPanel = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        subjectPageTable = new javax.swing.JTable();
        subjectPageSaveBtn = new javax.swing.JButton();
        subjectPageEditBtn = new javax.swing.JButton();
        subjectPageClearBtn = new javax.swing.JButton();
        subjectPageDeleteBtn = new javax.swing.JButton();
        studentPanel = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        jLabel28 = new javax.swing.JLabel();
        studentPageID = new javax.swing.JTextField();
        jLabel29 = new javax.swing.JLabel();
        studentPageStudentNumber = new javax.swing.JTextField();
        jLabel30 = new javax.swing.JLabel();
        studentPageLastName = new javax.swing.JTextField();
        jLabel32 = new javax.swing.JLabel();
        studentPageFirstName = new javax.swing.JTextField();
        jLabel33 = new javax.swing.JLabel();
        studentPageEmail = new javax.swing.JTextField();
        jLabel34 = new javax.swing.JLabel();
        studentPagePhone = new javax.swing.JTextField();
        jLabel35 = new javax.swing.JLabel();
        studentPageGender = new javax.swing.JComboBox<>();
        jLabel36 = new javax.swing.JLabel();
        studentPageUserType = new javax.swing.JComboBox<>();
        jLabel37 = new javax.swing.JLabel();
        studentPagePassword = new javax.swing.JPasswordField();
        jPanel13 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        studentPageTable = new javax.swing.JTable();
        studentPageSaveBtn = new javax.swing.JButton();
        studentPageEditBtn = new javax.swing.JButton();
        studentPageClearBtn = new javax.swing.JButton();
        studentPageDeleteBtn = new javax.swing.JButton();
        professorPanel = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        professorPageID = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        professorPageAccountID = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        professorPageLastName = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        professorPageFirstName = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        professorPageEmail = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        professorPagePhone = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        professorPageUserType = new javax.swing.JComboBox<>();
        jLabel10 = new javax.swing.JLabel();
        professorPagePassword = new javax.swing.JPasswordField();
        jLabel2 = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        professorPageTable = new javax.swing.JTable();
        professorPageSaveBtn = new javax.swing.JButton();
        professorPageEditBtn = new javax.swing.JButton();
        professorPageClearBtn = new javax.swing.JButton();
        professorPageDeleteBtn = new javax.swing.JButton();
        labelNTCLogo = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(252, 250, 248));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(3, 4, 94));

        jButton1.setBackground(new java.awt.Color(250, 249, 246));
        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton1.setText("View Attendance");
        jButton1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setBackground(new java.awt.Color(250, 249, 246));
        jButton2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton2.setText("Add Class");
        jButton2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setBackground(new java.awt.Color(250, 249, 246));
        jButton3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton3.setText("Add Subject");
        jButton3.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setBackground(new java.awt.Color(250, 249, 246));
        jButton4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton4.setText("Register Student");
        jButton4.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jButton5.setBackground(new java.awt.Color(250, 249, 246));
        jButton5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton5.setText("Register Professor");
        jButton5.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jButton7.setBackground(new java.awt.Color(250, 249, 246));
        jButton7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton7.setForeground(new java.awt.Color(255, 0, 0));
        jButton7.setText("Logout");
        jButton7.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jButton4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton5, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                    .addComponent(jButton7, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(28, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(116, 116, 116)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 68, Short.MAX_VALUE)
                .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(64, 64, 64))
        );

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 160, 250, 500));

        jPanel3.setBackground(new java.awt.Color(249, 245, 240));
        jPanel3.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        attendancePanel.setBackground(new java.awt.Color(3, 4, 94));

        jPanel14.setBackground(new java.awt.Color(249, 245, 240));

        viewAttendancePageTable.setBackground(new java.awt.Color(250, 249, 246));
        viewAttendancePageTable.setFont(new java.awt.Font("Segoe UI Black", 1, 12)); // NOI18N
        viewAttendancePageTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Student Number", "Student Name", "Subject", "Section", "Room", "Time In", "Date", "Time out"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        viewAttendancePageTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                viewAttendancePageTableMouseClicked(evt);
            }
        });
        jScrollPane5.setViewportView(viewAttendancePageTable);

        javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
        jPanel14.setLayout(jPanel14Layout);
        jPanel14Layout.setHorizontalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 994, Short.MAX_VALUE)
        );
        jPanel14Layout.setVerticalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 488, Short.MAX_VALUE)
        );

        viewAttendancePageSearchField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                viewAttendancePageSearchFieldKeyReleased(evt);
            }
        });

        jButton6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton6.setText("Search");
        jButton6.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout attendancePanelLayout = new javax.swing.GroupLayout(attendancePanel);
        attendancePanel.setLayout(attendancePanelLayout);
        attendancePanelLayout.setHorizontalGroup(
            attendancePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(attendancePanelLayout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(attendancePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(attendancePanelLayout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addComponent(viewAttendancePageSearchField, javax.swing.GroupLayout.PREFERRED_SIZE, 235, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(21, Short.MAX_VALUE))
        );
        attendancePanelLayout.setVerticalGroup(
            attendancePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(attendancePanelLayout.createSequentialGroup()
                .addGap(58, 58, 58)
                .addGroup(attendancePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(viewAttendancePageSearchField, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jPanel14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("tab1", attendancePanel);

        ClassPanel.setBackground(new java.awt.Color(3, 4, 94));

        jPanel5.setBackground(new java.awt.Color(3, 4, 94));

        jLabel23.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel23.setForeground(new java.awt.Color(255, 255, 255));
        jLabel23.setText("Student Number");

        classPageSearchField.setBorder(null);

        classPageSearchbtn.setBackground(new java.awt.Color(250, 249, 246));
        classPageSearchbtn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        classPageSearchbtn.setText("Search");
        classPageSearchbtn.setBorder(null);
        classPageSearchbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                classPageSearchbtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel23)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(classPageSearchField, javax.swing.GroupLayout.PREFERRED_SIZE, 236, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(30, 30, 30)
                        .addComponent(classPageSearchbtn, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(31, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel23)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(classPageSearchField, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(classPageSearchbtn, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel12.setBackground(new java.awt.Color(3, 4, 94));

        jLabel24.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel24.setForeground(new java.awt.Color(255, 255, 255));
        jLabel24.setText("ID");

        jLabel25.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel25.setForeground(new java.awt.Color(255, 255, 255));
        jLabel25.setText("Student Number");

        jLabel26.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel26.setForeground(new java.awt.Color(255, 255, 255));
        jLabel26.setText("Student Name");

        jLabel27.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel27.setForeground(new java.awt.Color(255, 255, 255));
        jLabel27.setText("Subject");

        classPageSubject.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                classPageSubjectMouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                classPageSubjectMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                classPageSubjectMouseReleased(evt);
            }
        });
        classPageSubject.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                classPageSubjectActionPerformed(evt);
            }
        });

        jLabel38.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel38.setForeground(new java.awt.Color(255, 255, 255));
        jLabel38.setText("Start Time");

        classPageStartTime.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "6:00", "7:00", "8:00", "9:00", "10:00", "11:00", "12:00", "13:00", "14:00", "15:00", "16:00", "17:00", "18:00", "19:00", "20:00", "21:00" }));

        jLabel39.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel39.setForeground(new java.awt.Color(255, 255, 255));
        jLabel39.setText("End Time");

        classPageEndTime.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "7:00", "8:00", "9:00", "10:00", "11:00", "12:00", "13:00", "14:00", "15:00", "16:00", "17:00", "18:00", "19:00", "20:00", "21:00" }));

        jLabel40.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel40.setForeground(new java.awt.Color(255, 255, 255));
        jLabel40.setText("Days");

        jLabel41.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel41.setForeground(new java.awt.Color(255, 255, 255));
        jLabel41.setText("Room");

        jLabel42.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel42.setForeground(new java.awt.Color(255, 255, 255));
        jLabel42.setText("Section");

        classPageSection.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                classPageSectionActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel25))
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addComponent(jLabel24))
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel26))
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel27))
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel41))
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel40))
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel39))
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel38))
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel42, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(33, 33, 33)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(classPageStartTime, 0, 208, Short.MAX_VALUE)
                    .addComponent(classPageEndTime, 0, 208, Short.MAX_VALUE)
                    .addComponent(classPageDays, javax.swing.GroupLayout.DEFAULT_SIZE, 208, Short.MAX_VALUE)
                    .addComponent(classPageRoom, javax.swing.GroupLayout.DEFAULT_SIZE, 208, Short.MAX_VALUE)
                    .addComponent(classPageID)
                    .addComponent(classPageStudentNumber)
                    .addComponent(classPageStudentName)
                    .addComponent(classPageSubject, 0, 208, Short.MAX_VALUE)
                    .addComponent(classPageSection, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel24)
                    .addComponent(classPageID, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(22, 22, 22)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel25)
                    .addComponent(classPageStudentNumber, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(22, 22, 22)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel26)
                    .addComponent(classPageStudentName, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(22, 22, 22)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel27)
                    .addComponent(classPageSubject, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel42)
                    .addComponent(classPageSection, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 22, Short.MAX_VALUE)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel38)
                    .addComponent(classPageStartTime, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(22, 22, 22)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel39)
                    .addComponent(classPageEndTime, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(22, 22, 22)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel40)
                    .addComponent(classPageDays, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(22, 22, 22)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel41)
                    .addComponent(classPageRoom, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24))
        );

        jPanel15.setBackground(new java.awt.Color(3, 4, 94));

        classPageTable.setBackground(new java.awt.Color(250, 249, 246));
        classPageTable.setFont(new java.awt.Font("Segoe UI Black", 1, 12)); // NOI18N
        classPageTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Student Number", "Student Name", "Subject", "Section", "Start Time", "End Time", "Days", "Room"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        classPageTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                classPageTableMouseClicked(evt);
            }
        });
        jScrollPane4.setViewportView(classPageTable);

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 605, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 494, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        classPageEditBtn.setBackground(new java.awt.Color(250, 249, 246));
        classPageEditBtn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        classPageEditBtn.setText("Update");
        classPageEditBtn.setBorder(null);
        classPageEditBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                classPageEditBtnActionPerformed(evt);
            }
        });

        classPageClearBtn.setBackground(new java.awt.Color(250, 249, 246));
        classPageClearBtn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        classPageClearBtn.setText("Clear");
        classPageClearBtn.setBorder(null);
        classPageClearBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                classPageClearBtnActionPerformed(evt);
            }
        });

        classPageDeleteBtn.setBackground(new java.awt.Color(250, 249, 246));
        classPageDeleteBtn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        classPageDeleteBtn.setForeground(new java.awt.Color(255, 0, 0));
        classPageDeleteBtn.setText("Delete");
        classPageDeleteBtn.setBorder(null);
        classPageDeleteBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                classPageDeleteBtnActionPerformed(evt);
            }
        });

        classPageSaveBtn.setBackground(new java.awt.Color(250, 249, 246));
        classPageSaveBtn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        classPageSaveBtn.setText("Save");
        classPageSaveBtn.setBorder(null);
        classPageSaveBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                classPageSaveBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout ClassPanelLayout = new javax.swing.GroupLayout(ClassPanel);
        ClassPanel.setLayout(ClassPanelLayout);
        ClassPanelLayout.setHorizontalGroup(
            ClassPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ClassPanelLayout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(ClassPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(ClassPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(ClassPanelLayout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(classPageSaveBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(classPageEditBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(classPageClearBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(classPageDeleteBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        ClassPanelLayout.setVerticalGroup(
            ClassPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ClassPanelLayout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(ClassPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(ClassPanelLayout.createSequentialGroup()
                        .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(ClassPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(classPageEditBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(classPageClearBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(classPageDeleteBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(classPageSaveBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(ClassPanelLayout.createSequentialGroup()
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(33, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("tab2", ClassPanel);

        SubjectPanel.setBackground(new java.awt.Color(3, 4, 94));

        jPanel6.setBackground(new java.awt.Color(3, 4, 94));

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("Student Number");

        subjectPageSearchBtn.setBackground(new java.awt.Color(250, 249, 246));
        subjectPageSearchBtn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        subjectPageSearchBtn.setText("Search");
        subjectPageSearchBtn.setBorder(null);
        subjectPageSearchBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                subjectPageSearchBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jLabel12)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(subjectPageSearchField, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 29, Short.MAX_VALUE)
                        .addComponent(subjectPageSearchBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(27, 27, 27))))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel12)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(subjectPageSearchField, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(subjectPageSearchBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(13, Short.MAX_VALUE))
        );

        jPanel11.setBackground(new java.awt.Color(3, 4, 94));
        jPanel11.setForeground(new java.awt.Color(255, 255, 255));

        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setText("Student Number");

        subjectPageStudentNumber.setEditable(false);

        jLabel19.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(255, 255, 255));
        jLabel19.setText("ID");

        jLabel20.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(255, 255, 255));
        jLabel20.setText("Student Name");

        subjectPageStudentName.setEditable(false);

        jLabel14.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jLabel14.setText("Year Level");

        jLabel15.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
        jLabel15.setText("Semester");

        subjectPageSemester.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "First Semester", "Second Semester" }));

        subjectPageYearLevel.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "First Year", "Second Year", "Third Year", "Fourth Year" }));

        jLabel16.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(255, 255, 255));
        jLabel16.setText("Type of Student");

        subjectPageTypeOfStudent.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Regular", "Irregular" }));
        subjectPageTypeOfStudent.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                subjectPageTypeOfStudentActionPerformed(evt);
            }
        });

        jLabel17.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(255, 255, 255));
        jLabel17.setText("Subject 1");

        jLabel18.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(255, 255, 255));
        jLabel18.setText("Subject 2");

        jLabel21.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(255, 255, 255));
        jLabel21.setText("Subject 3");

        jLabel22.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(255, 255, 255));
        jLabel22.setText("Subject 4");

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel13)
                    .addComponent(jLabel19)
                    .addComponent(jLabel20)
                    .addComponent(jLabel14)
                    .addComponent(jLabel15)
                    .addComponent(jLabel16)
                    .addComponent(jLabel17)
                    .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel21)
                    .addComponent(jLabel22))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 32, Short.MAX_VALUE)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(subjectPageStudentNumber)
                    .addComponent(subjectPageID)
                    .addComponent(subjectPageStudentName)
                    .addComponent(subjectPageSemester, 0, 189, Short.MAX_VALUE)
                    .addComponent(subjectPageYearLevel, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(subjectPageTypeOfStudent, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(subjectPageSubject1, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(subjectPageSubject2, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(subjectPageSubject3, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(subjectPageSubject4, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(15, 15, 15))
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel19)
                    .addComponent(subjectPageID, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13)
                    .addComponent(subjectPageStudentNumber, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel20)
                    .addComponent(subjectPageStudentName, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel14)
                    .addComponent(subjectPageYearLevel, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(17, 17, 17)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel15)
                    .addComponent(subjectPageSemester, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(17, 17, 17)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel16)
                    .addComponent(subjectPageTypeOfStudent, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel17)
                    .addComponent(subjectPageSubject1, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(17, 17, 17)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel18)
                    .addComponent(subjectPageSubject2, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(17, 17, 17)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel21)
                    .addComponent(subjectPageSubject3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel22)
                    .addComponent(subjectPageSubject4, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(46, Short.MAX_VALUE))
        );

        subjectPanel.setBackground(new java.awt.Color(3, 4, 94));

        subjectPageTable.setBackground(new java.awt.Color(250, 249, 246));
        subjectPageTable.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        subjectPageTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Student Number", "Student Name", "Year Level", "Semester", "Type of Student", "Subject 1", "Subject 2", "Subject 3", "Subject 4"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        subjectPageTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                subjectPageTableMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(subjectPageTable);

        javax.swing.GroupLayout subjectPanelLayout = new javax.swing.GroupLayout(subjectPanel);
        subjectPanel.setLayout(subjectPanelLayout);
        subjectPanelLayout.setHorizontalGroup(
            subjectPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(subjectPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 641, Short.MAX_VALUE)
                .addContainerGap())
        );
        subjectPanelLayout.setVerticalGroup(
            subjectPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(subjectPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane3)
                .addContainerGap())
        );

        subjectPageSaveBtn.setBackground(new java.awt.Color(250, 249, 246));
        subjectPageSaveBtn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        subjectPageSaveBtn.setText("Save");
        subjectPageSaveBtn.setBorder(null);
        subjectPageSaveBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                subjectPageSaveBtnActionPerformed(evt);
            }
        });

        subjectPageEditBtn.setBackground(new java.awt.Color(250, 249, 246));
        subjectPageEditBtn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        subjectPageEditBtn.setText("Update");
        subjectPageEditBtn.setBorder(null);
        subjectPageEditBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                subjectPageEditBtnActionPerformed(evt);
            }
        });

        subjectPageClearBtn.setBackground(new java.awt.Color(250, 249, 246));
        subjectPageClearBtn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        subjectPageClearBtn.setText("Clear");
        subjectPageClearBtn.setBorder(null);
        subjectPageClearBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                subjectPageClearBtnActionPerformed(evt);
            }
        });

        subjectPageDeleteBtn.setBackground(new java.awt.Color(250, 249, 246));
        subjectPageDeleteBtn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        subjectPageDeleteBtn.setForeground(new java.awt.Color(255, 0, 0));
        subjectPageDeleteBtn.setText("Delete");
        subjectPageDeleteBtn.setBorder(null);
        subjectPageDeleteBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                subjectPageDeleteBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout SubjectPanelLayout = new javax.swing.GroupLayout(SubjectPanel);
        SubjectPanel.setLayout(SubjectPanelLayout);
        SubjectPanelLayout.setHorizontalGroup(
            SubjectPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SubjectPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(SubjectPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(SubjectPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(SubjectPanelLayout.createSequentialGroup()
                        .addComponent(subjectPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())
                    .addGroup(SubjectPanelLayout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(subjectPageSaveBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(subjectPageEditBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(subjectPageClearBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(subjectPageDeleteBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        SubjectPanelLayout.setVerticalGroup(
            SubjectPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SubjectPanelLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(SubjectPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(SubjectPanelLayout.createSequentialGroup()
                        .addComponent(subjectPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(SubjectPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(subjectPageSaveBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(subjectPageEditBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(subjectPageClearBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(subjectPageDeleteBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(15, 15, 15))
                    .addGroup(SubjectPanelLayout.createSequentialGroup()
                        .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())))
        );

        jTabbedPane1.addTab("tab3", SubjectPanel);

        studentPanel.setBackground(new java.awt.Color(3, 4, 94));

        jPanel7.setBackground(new java.awt.Color(249, 245, 240));

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 201, Short.MAX_VALUE)
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 124, Short.MAX_VALUE)
        );

        jLabel11.setFont(new java.awt.Font("Segoe UI Black", 1, 24)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Register Student Account");

        jPanel10.setBackground(new java.awt.Color(3, 4, 94));

        jLabel28.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel28.setForeground(new java.awt.Color(255, 255, 255));
        jLabel28.setText("ID");

        jLabel29.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel29.setForeground(new java.awt.Color(255, 255, 255));
        jLabel29.setText("Student Number");

        jLabel30.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel30.setForeground(new java.awt.Color(255, 255, 255));
        jLabel30.setText("Last Name");

        jLabel32.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel32.setForeground(new java.awt.Color(255, 255, 255));
        jLabel32.setText("First Name");

        jLabel33.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel33.setForeground(new java.awt.Color(255, 255, 255));
        jLabel33.setText("Email");

        jLabel34.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel34.setForeground(new java.awt.Color(255, 255, 255));
        jLabel34.setText("Phone");

        jLabel35.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel35.setForeground(new java.awt.Color(255, 255, 255));
        jLabel35.setText("Gender");

        studentPageGender.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Male", "Female" }));

        jLabel36.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel36.setForeground(new java.awt.Color(255, 255, 255));
        jLabel36.setText("User Type");

        studentPageUserType.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Student", "Admin" }));

        jLabel37.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel37.setForeground(new java.awt.Color(255, 255, 255));
        jLabel37.setText("Password");

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel29)
                    .addComponent(jLabel28)
                    .addComponent(jLabel30)
                    .addComponent(jLabel32)
                    .addComponent(jLabel33)
                    .addComponent(jLabel34)
                    .addComponent(jLabel35)
                    .addComponent(jLabel36)
                    .addComponent(jLabel37))
                .addGap(34, 34, 34)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(studentPageID)
                    .addComponent(studentPageStudentNumber)
                    .addComponent(studentPageLastName)
                    .addComponent(studentPageFirstName)
                    .addComponent(studentPageEmail)
                    .addComponent(studentPagePhone)
                    .addComponent(studentPageGender, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(studentPageUserType, 0, 254, Short.MAX_VALUE)
                    .addComponent(studentPagePassword))
                .addContainerGap(18, Short.MAX_VALUE))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel28)
                    .addComponent(studentPageID, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel29)
                    .addComponent(studentPageStudentNumber, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel30)
                    .addComponent(studentPageLastName, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel32)
                    .addComponent(studentPageFirstName, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel33)
                    .addComponent(studentPageEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel34)
                    .addComponent(studentPagePhone, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel35)
                    .addComponent(studentPageGender, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel36)
                    .addComponent(studentPageUserType, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(23, 23, 23)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel37)
                    .addComponent(studentPagePassword, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(30, Short.MAX_VALUE))
        );

        jPanel13.setBackground(new java.awt.Color(3, 4, 94));

        studentPageTable.setBackground(new java.awt.Color(250, 249, 246));
        studentPageTable.setFont(new java.awt.Font("Segoe UI Black", 1, 12)); // NOI18N
        studentPageTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Student Number", "Last Name", "First Name", "Email", "Phone", "Gender", "User Type", "Password"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        studentPageTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                studentPageTableMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(studentPageTable);

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 533, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 497, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(14, Short.MAX_VALUE))
        );

        studentPageSaveBtn.setBackground(new java.awt.Color(250, 249, 246));
        studentPageSaveBtn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        studentPageSaveBtn.setText("Save");
        studentPageSaveBtn.setBorder(null);
        studentPageSaveBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                studentPageSaveBtnActionPerformed(evt);
            }
        });

        studentPageEditBtn.setBackground(new java.awt.Color(250, 249, 246));
        studentPageEditBtn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        studentPageEditBtn.setText("Update");
        studentPageEditBtn.setBorder(null);
        studentPageEditBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                studentPageEditBtnActionPerformed(evt);
            }
        });

        studentPageClearBtn.setBackground(new java.awt.Color(250, 249, 246));
        studentPageClearBtn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        studentPageClearBtn.setText("Clear");
        studentPageClearBtn.setBorder(null);
        studentPageClearBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                studentPageClearBtnActionPerformed(evt);
            }
        });

        studentPageDeleteBtn.setBackground(new java.awt.Color(250, 249, 246));
        studentPageDeleteBtn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        studentPageDeleteBtn.setForeground(new java.awt.Color(255, 51, 0));
        studentPageDeleteBtn.setText("Delete");
        studentPageDeleteBtn.setBorder(null);
        studentPageDeleteBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                studentPageDeleteBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout studentPanelLayout = new javax.swing.GroupLayout(studentPanel);
        studentPanel.setLayout(studentPanelLayout);
        studentPanelLayout.setHorizontalGroup(
            studentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(studentPanelLayout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(studentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel11)
                    .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(studentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(studentPanelLayout.createSequentialGroup()
                        .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(11, 11, 11)
                        .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(studentPanelLayout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(studentPageSaveBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(studentPageEditBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(studentPageClearBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(studentPageDeleteBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        studentPanelLayout.setVerticalGroup(
            studentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(studentPanelLayout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(studentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(studentPanelLayout.createSequentialGroup()
                        .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(studentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(studentPageSaveBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(studentPageEditBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(studentPageClearBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(studentPageDeleteBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(studentPanelLayout.createSequentialGroup()
                        .addComponent(jLabel11)
                        .addGroup(studentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(studentPanelLayout.createSequentialGroup()
                                .addGap(33, 33, 33)
                                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(studentPanelLayout.createSequentialGroup()
                                .addGap(11, 11, 11)
                                .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(25, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Register Student", studentPanel);

        professorPanel.setBackground(new java.awt.Color(3, 4, 94));

        jPanel8.setBackground(new java.awt.Color(3, 4, 94));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("ID");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Account ID");

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Last Name");

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("First Name");

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Email");

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Phone");

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("User Type");

        professorPageUserType.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Admin", "Student" }));

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Password");

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addComponent(jLabel4)
                    .addComponent(jLabel5)
                    .addComponent(jLabel6)
                    .addComponent(jLabel7)
                    .addComponent(jLabel8)
                    .addComponent(jLabel9)
                    .addComponent(jLabel10))
                .addGap(74, 74, 74)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(professorPageID)
                    .addComponent(professorPageAccountID)
                    .addComponent(professorPageLastName)
                    .addComponent(professorPageFirstName)
                    .addComponent(professorPageEmail)
                    .addComponent(professorPagePhone)
                    .addComponent(professorPageUserType, 0, 249, Short.MAX_VALUE)
                    .addComponent(professorPagePassword))
                .addContainerGap(14, Short.MAX_VALUE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(professorPageID, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(professorPageAccountID, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(professorPageLastName, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(professorPageFirstName, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(professorPageEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(professorPagePhone, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(professorPageUserType, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(professorPagePassword, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(30, Short.MAX_VALUE))
        );

        jLabel2.setFont(new java.awt.Font("Segoe UI Black", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Register Professor Account");

        jPanel9.setBackground(new java.awt.Color(3, 4, 94));
        jPanel9.setForeground(new java.awt.Color(255, 255, 255));

        professorPageTable.setBackground(new java.awt.Color(250, 249, 246));
        professorPageTable.setFont(new java.awt.Font("Segoe UI Black", 1, 12)); // NOI18N
        professorPageTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Account ID", "Last Name", "First Name", "Email", "Phone", "User Type", "Password"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        professorPageTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                professorPageTableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(professorPageTable);

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 536, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 488, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        professorPageSaveBtn.setBackground(new java.awt.Color(250, 249, 246));
        professorPageSaveBtn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        professorPageSaveBtn.setText("Save");
        professorPageSaveBtn.setBorder(null);
        professorPageSaveBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                professorPageSaveBtnActionPerformed(evt);
            }
        });

        professorPageEditBtn.setBackground(new java.awt.Color(250, 249, 246));
        professorPageEditBtn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        professorPageEditBtn.setText("Update");
        professorPageEditBtn.setBorder(null);
        professorPageEditBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                professorPageEditBtnActionPerformed(evt);
            }
        });

        professorPageClearBtn.setBackground(new java.awt.Color(250, 249, 246));
        professorPageClearBtn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        professorPageClearBtn.setText("Clear");
        professorPageClearBtn.setBorder(null);
        professorPageClearBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                professorPageClearBtnActionPerformed(evt);
            }
        });

        professorPageDeleteBtn.setBackground(new java.awt.Color(250, 249, 246));
        professorPageDeleteBtn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        professorPageDeleteBtn.setForeground(new java.awt.Color(255, 0, 0));
        professorPageDeleteBtn.setText("Delete");
        professorPageDeleteBtn.setBorder(null);
        professorPageDeleteBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                professorPageDeleteBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout professorPanelLayout = new javax.swing.GroupLayout(professorPanel);
        professorPanel.setLayout(professorPanelLayout);
        professorPanelLayout.setHorizontalGroup(
            professorPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(professorPanelLayout.createSequentialGroup()
                .addGroup(professorPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(professorPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(professorPanelLayout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addComponent(jLabel2)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(30, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, professorPanelLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(professorPageSaveBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addComponent(professorPageEditBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addComponent(professorPageClearBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addComponent(professorPageDeleteBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(159, 159, 159))
        );
        professorPanelLayout.setVerticalGroup(
            professorPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(professorPanelLayout.createSequentialGroup()
                .addGroup(professorPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(professorPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(professorPanelLayout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(professorPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(professorPageSaveBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(professorPageEditBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(professorPageClearBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(professorPageDeleteBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(25, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Register Professor", professorPanel);

        jPanel3.add(jTabbedPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -40, 1030, 630));

        jPanel1.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 130, 1030, 590));

        labelNTCLogo.setBackground(new java.awt.Color(250, 249, 246));
        labelNTCLogo.setFont(new java.awt.Font("Segoe UI Black", 1, 48)); // NOI18N
        labelNTCLogo.setForeground(new java.awt.Color(250, 249, 246));
        labelNTCLogo.setText("National Teachers College");
        jPanel1.add(labelNTCLogo, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 30, -1, -1));

        jLabel31.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/iconLogoNtccc.png"))); // NOI18N
        jPanel1.add(jLabel31, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 20, 120, 100));

        jLabel1.setBackground(new java.awt.Color(3, 4, 94));
        jLabel1.setOpaque(true);
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1280, 720));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        jTabbedPane1.setSelectedIndex(0);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        jTabbedPane1.setSelectedIndex(1);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        jTabbedPane1.setSelectedIndex(2);
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        jTabbedPane1.setSelectedIndex(3);
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        jTabbedPane1.setSelectedIndex(4);
    }//GEN-LAST:event_jButton5ActionPerformed

    private void professorPageSaveBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_professorPageSaveBtnActionPerformed
        if (isProfessorPageFieldEmpty()) {
            if (!professoraccountregistration.isProfessorEmailExist(professorPageEmail.getText())) {
                if (!professoraccountregistration.isProfessorPhoneExist(professorPagePhone.getText())) {
                    int id = professoraccountregistration.getMax();
                    String accountID = professorPageAccountID.getText();
                    String lastName = professorPageLastName.getText();
                    String firstName = professorPageFirstName.getText();
                    String email = professorPageEmail.getText();
                    String phone = professorPagePhone.getText();
                    String userType = professorPageUserType.getSelectedItem().toString();
                    String password = professorPagePassword.getText();
                    professoraccountregistration.insert(id, accountID, lastName, firstName, email, phone, userType, password);
                    professorPageTable.setModel(new DefaultTableModel(null, new Object[]{"ID", "Account ID", "Last Name", "First Name", "Email", "Phone", "User Type", "Password"}));
                    professoraccountregistration.getProfessorAccountDatabase(professorPageTable, "");
                    professorPageClearField();
                } else {
                    JOptionPane.showMessageDialog(this, "Sorry, phone number already exist");
                }
            } else {
                JOptionPane.showMessageDialog(this, "Sorry, email address already exist");
            }
        }
    }//GEN-LAST:event_professorPageSaveBtnActionPerformed

    private void professorPageTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_professorPageTableMouseClicked
        model = (DefaultTableModel) professorPageTable.getModel();
        rowIndex = professorPageTable.getSelectedRow();
        professorPageID.setText(model.getValueAt(rowIndex, 0).toString());
        professorPageAccountID.setText(model.getValueAt(rowIndex, 1).toString());
        professorPageLastName.setText(model.getValueAt(rowIndex, 2).toString());
        professorPageFirstName.setText(model.getValueAt(rowIndex, 3).toString());
        professorPageEmail.setText(model.getValueAt(rowIndex, 4).toString());
        professorPagePhone.setText(model.getValueAt(rowIndex, 5).toString());
        String userType = model.getValueAt(rowIndex, 6).toString();
        if (userType.equals("Admin")) {
            professorPageUserType.setSelectedIndex(0);
        } else {
            professorPageUserType.setSelectedIndex(0);
        }
        professorPagePassword.setText(model.getValueAt(rowIndex, 7).toString());

    }//GEN-LAST:event_professorPageTableMouseClicked

    private void professorPageEditBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_professorPageEditBtnActionPerformed
        if (isProfessorPageFieldEmpty()) {
            int id = Integer.parseInt(professorPageID.getText());
            if (professoraccountregistration.isProfessorIdExist(id)) {
                if (!checkProfessorPage()) {
                    String accountID = professorPageAccountID.getText();
                    String lastName = professorPageLastName.getText();
                    String firstName = professorPageFirstName.getText();
                    String email = professorPageEmail.getText();
                    String phone = professorPagePhone.getText();
                    String userType = professorPageUserType.getSelectedItem().toString();
                    String password = professorPagePassword.getText();
                    professoraccountregistration.update(id, accountID, lastName, firstName, email, phone, userType, password);
                    professorPageTable.setModel(new DefaultTableModel(null, new Object[]{"ID", "Account ID", "Last Name", "First Name", "Email", "Phone", "User Type", "Password"}));
                    professoraccountregistration.getProfessorAccountDatabase(professorPageTable, "");
                    professorPageClearField();
                }

            } else {
                JOptionPane.showMessageDialog(this, "Student ID doesn't exist! ");
            }
        }
    }//GEN-LAST:event_professorPageEditBtnActionPerformed

    private void professorPageClearBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_professorPageClearBtnActionPerformed
        professorPageClearField();
    }//GEN-LAST:event_professorPageClearBtnActionPerformed

    private void professorPageDeleteBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_professorPageDeleteBtnActionPerformed
        int id = Integer.parseInt(professorPageID.getText());
        if (professoraccountregistration.isProfessorIdExist(id)) {
            professoraccountregistration.delete(id);
            professorPageTable.setModel(new DefaultTableModel(null, new Object[]{"ID", "Account ID", "Last Name", "First Name", "Email", "Phone", "User Type", "Password"}));
            professoraccountregistration.getProfessorAccountDatabase(professorPageTable, "");
            professorPageClearField();
        } else {
            JOptionPane.showMessageDialog(this, "Sorry, Professor account id doesn't exists");
        }
    }//GEN-LAST:event_professorPageDeleteBtnActionPerformed

    private void studentPageTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_studentPageTableMouseClicked
        model = (DefaultTableModel) studentPageTable.getModel();
        rowIndex = studentPageTable.getSelectedRow();
        studentPageID.setText(model.getValueAt(rowIndex, 0).toString());
        studentPageStudentNumber.setText(model.getValueAt(rowIndex, 1).toString());
        studentPageLastName.setText(model.getValueAt(rowIndex, 2).toString());
        studentPageFirstName.setText(model.getValueAt(rowIndex, 3).toString());
        studentPageEmail.setText(model.getValueAt(rowIndex, 4).toString());
        studentPagePhone.setText(model.getValueAt(rowIndex, 5).toString());
        String gender = model.getValueAt(rowIndex, 6).toString();
        if (gender.equals("Male")) {
            studentPageGender.setSelectedIndex(0);
        } else {
            studentPageGender.setSelectedIndex(1);
        }
        String userType = model.getValueAt(rowIndex, 7).toString();
        if (userType.equals("Student")) {
            studentPageUserType.setSelectedIndex(0);
        } else {
            studentPageUserType.setSelectedIndex(0);
        }
        studentPagePassword.setText(model.getValueAt(rowIndex, 8).toString());
    }//GEN-LAST:event_studentPageTableMouseClicked

    private void studentPageSaveBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_studentPageSaveBtnActionPerformed
        if (isStudentPageFieldEmpty()) {
            if (!studentaccountregistration.isStudentEmailExist(studentPageEmail.getText())) {
                if (!studentaccountregistration.isStudentPhoneExist(studentPagePhone.getText())) {
                    int id = studentaccountregistration.getMax();
                    String studentNumber = studentPageStudentNumber.getText();
                    String lastName = studentPageLastName.getText();
                    String firstName = studentPageFirstName.getText();
                    String email = studentPageEmail.getText();
                    String phone = studentPagePhone.getText();
                    String gender = studentPageGender.getSelectedItem().toString();
                    String userType = studentPageUserType.getSelectedItem().toString();
                    String password = studentPagePassword.getText();
                    studentaccountregistration.insert(id, studentNumber, lastName, firstName, email, phone, gender, userType, password);
                    studentPageTable.setModel(new DefaultTableModel(null, new Object[]{"ID", "Student Number", "Last Name", "First Name", "Email", "Phone", "Gender", "User Type", "Password"}));
                    studentaccountregistration.getStudentAccountDatabase(studentPageTable, "");
                    studentPageClearField();
                } else {
                    JOptionPane.showMessageDialog(this, "Sorry, phone number already exist");
                }
            } else {
                JOptionPane.showMessageDialog(this, "Sorry, email address already exist");
            }
        }
    }//GEN-LAST:event_studentPageSaveBtnActionPerformed

    private void studentPageEditBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_studentPageEditBtnActionPerformed
        if (isStudentPageFieldEmpty()) {
            int id = Integer.parseInt(studentPageID.getText());
            if (studentaccountregistration.isStudentIdExist(id)) {
                if (!checkStudentPage()) {
                    String studentNumber = studentPageStudentNumber.getText();
                    String lastName = studentPageLastName.getText();
                    String firstName = studentPageFirstName.getText();
                    String email = studentPageEmail.getText();
                    String phone = studentPagePhone.getText();
                    String gender = studentPageGender.getSelectedItem().toString();
                    String userType = studentPageUserType.getSelectedItem().toString();
                    String password = studentPagePassword.getText();
                    studentaccountregistration.update(id, studentNumber, lastName, firstName, email, phone, gender, userType, password);
                    studentPageTable.setModel(new DefaultTableModel(null, new Object[]{"ID", "Student Number", "Last Name", "First Name", "Email", "Phone", "Gender", "User Type", "Password"}));
                    studentaccountregistration.getStudentAccountDatabase(studentPageTable, "");
                    studentPageClearField();
                }

            } else {
                JOptionPane.showMessageDialog(this, "Student ID doesn't exist! ");
            }
        }
    }//GEN-LAST:event_studentPageEditBtnActionPerformed

    private void studentPageClearBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_studentPageClearBtnActionPerformed
        studentPageClearField();
    }//GEN-LAST:event_studentPageClearBtnActionPerformed

    private void studentPageDeleteBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_studentPageDeleteBtnActionPerformed
        int id = Integer.parseInt(studentPageID.getText());
        if (studentaccountregistration.isStudentIdExist(id)) {
            studentaccountregistration.delete(id);
            studentPageTable.setModel(new DefaultTableModel(null, new Object[]{"ID", "Student Number", "Last Name", "First Name", "Email", "Phone", "Gender", "User Type", "Password"}));
            studentaccountregistration.getStudentAccountDatabase(studentPageTable, "");
            studentPageClearField();
        } else {
            JOptionPane.showMessageDialog(this, "Sorry, Student number doesn't exists");
        }
    }//GEN-LAST:event_studentPageDeleteBtnActionPerformed

    private void subjectPageSearchBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_subjectPageSearchBtnActionPerformed
        subjectpage.getSubjectSearchBtn();
    }//GEN-LAST:event_subjectPageSearchBtnActionPerformed

    private void subjectPageSaveBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_subjectPageSaveBtnActionPerformed
        if (subjectPageStudentNumber.getText().isEmpty() || subjectPageStudentName.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter student number ");
        } else {
            int id = subjectpage.getMax();
            int studentNumber = Integer.parseInt(subjectPageStudentNumber.getText());
            String studentName = subjectPageStudentName.getText();
            String yearLevel = subjectPageYearLevel.getSelectedItem().toString();
            String semester = subjectPageSemester.getSelectedItem().toString();
            String typeOfStudent = subjectPageTypeOfStudent.getSelectedItem().toString();
            String subject1 = subjectPageSubject1.getSelectedItem().toString();
            String subject2 = subjectPageSubject2.getSelectedItem().toString();
            String subject3 = subjectPageSubject3.getSelectedItem().toString();
            String subject4 = subjectPageSubject4.getSelectedItem().toString();
            if (subjectpage.isSemesterExist(studentNumber, semester)) {
                JOptionPane.showMessageDialog(this, "This student has already taken semester " + semester);
            } else {
                if (subjectpage.isSubjectExist(studentNumber, "subject1", subject1)) {
                    JOptionPane.showMessageDialog(this, "this student has already taken" + subject1 + "subject");
                } else {
                    if (subjectpage.isSubjectExist(studentNumber, "subject2", subject2)) {
                        JOptionPane.showMessageDialog(this, "this student has already taken" + subject2 + "subject");
                    } else {
                        if (subjectpage.isSubjectExist(studentNumber, "subject3", subject3)) {
                            JOptionPane.showMessageDialog(this, "this student has already taken" + subject3 + "subject");
                        } else {
                            if (subjectpage.isSubjectExist(studentNumber, "subject4", subject4)) {
                                JOptionPane.showMessageDialog(this, "this student has already taken" + subject4 + "subject");
                            } else {
                                subjectpage.insert(id, studentNumber, studentName, yearLevel, semester, typeOfStudent, subject1, subject2, subject3, subject4);
                                subjectPageTable.setModel(new DefaultTableModel(null, new Object[]{"ID", "Student Number", "Student Name", "Year Level",
                                    "Semester", "Type of Student", "Subject1", "Subject2", "Subject3", "Subject4"}));
                                subjectpage.getSubjectDatabase(subjectPageTable, "");
                                subjectPageClearField();
                            }
                        }
                    }
                }
            }

        }
    }//GEN-LAST:event_subjectPageSaveBtnActionPerformed

    private void subjectPageEditBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_subjectPageEditBtnActionPerformed
        if (isSubjectPageFieldEmpty()) {
            int id = Integer.parseInt(subjectPageID.getText());
            String studentNumber = subjectPageStudentNumber.getText();
            String studentName = subjectPageStudentName.getText();
            String yearLevel = subjectPageYearLevel.getSelectedItem().toString();
            String semester = subjectPageSemester.getSelectedItem().toString();
            String typeOfStudent = subjectPageTypeOfStudent.getSelectedItem().toString();
            String subject1 = subjectPageSubject1.getSelectedItem().toString();
            String subject2 = subjectPageSubject2.getSelectedItem().toString();
            String subject3 = subjectPageSubject3.getSelectedItem().toString();
            String subject4 = subjectPageSubject4.getSelectedItem().toString();
            subjectpage.update(id, studentNumber, studentName, yearLevel, semester, typeOfStudent, subject1, subject2, subject3, subject4);
            subjectPageTable.setModel(new DefaultTableModel(null, new Object[]{"ID", "Student Number", "Student Name", "Year Level",
                "Semester", "Type of Student", "Subject1", "Subject2", "Subject3", "Subject4"}));
            subjectpage.getSubjectDatabase(subjectPageTable, "");
            subjectPageClearField();
        } else {
            JOptionPane.showMessageDialog(this, "Student number doesn't exist");
        }
    }//GEN-LAST:event_subjectPageEditBtnActionPerformed

    private void subjectPageClearBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_subjectPageClearBtnActionPerformed
        subjectPageClearField();
    }//GEN-LAST:event_subjectPageClearBtnActionPerformed

    private void subjectPageDeleteBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_subjectPageDeleteBtnActionPerformed
        int id = Integer.parseInt(subjectPageID.getText());
        if (subjectpage.isStudentIdExist(id)) {
            subjectpage.delete(id);
            subjectPageTable.setModel(new DefaultTableModel(null, new Object[]{"ID", "Student Number", "Student Name", "Year Level", "Semester",
                "Type of Student", "subject 1", "subject 2", "subject 3", "subject 4"}));
            subjectpage.getSubjectDatabase(subjectPageTable, "");
            subjectPageClearField();
        } else {
            JOptionPane.showMessageDialog(this, "Sorry, Student number doesn't exists");
        }
    }//GEN-LAST:event_subjectPageDeleteBtnActionPerformed

    private void subjectPageTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_subjectPageTableMouseClicked
        model = (DefaultTableModel) subjectPageTable.getModel();
        rowIndex = subjectPageTable.getSelectedRow();
        subjectPageID.setText(model.getValueAt(rowIndex, 0).toString());
        subjectPageStudentNumber.setText(model.getValueAt(rowIndex, 1).toString());
        subjectPageStudentName.setText(model.getValueAt(rowIndex, 2).toString());
        String yearLevel = model.getValueAt(rowIndex, 3).toString();
        switch (yearLevel) {
            case "First Year" ->
                subjectPageYearLevel.setSelectedIndex(0);
            case "Second Year" ->
                subjectPageYearLevel.setSelectedIndex(1);
            case "Third Year" ->
                subjectPageYearLevel.setSelectedIndex(2);
            case "Fourth Year" ->
                subjectPageYearLevel.setSelectedIndex(3);
            default -> {
            }
        }
        String semester = model.getValueAt(rowIndex, 4).toString();
        if (semester.equals("First Semester")) {
            subjectPageSemester.setSelectedIndex(0);
        } else {
            subjectPageSemester.setSelectedIndex(1);
        }
        String typeOfStudent = model.getValueAt(rowIndex, 5).toString();
        if (typeOfStudent.equals("Regular")) {
            subjectPageTypeOfStudent.setSelectedIndex(0);
        } else {
            subjectPageTypeOfStudent.setSelectedIndex(1);
        }
        String subject1 = model.getValueAt(rowIndex, 6).toString();
        subjectPageSubject1.setSelectedItem(subject1);
        String subject2 = model.getValueAt(rowIndex, 7).toString();
        subjectPageSubject2.setSelectedItem(subject2);
        String subject3 = model.getValueAt(rowIndex, 8).toString();
        subjectPageSubject3.setSelectedItem(subject3);
        String subject4 = model.getValueAt(rowIndex, 9).toString();
        subjectPageSubject4.setSelectedItem(subject4);


    }//GEN-LAST:event_subjectPageTableMouseClicked

    private void subjectPageTypeOfStudentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_subjectPageTypeOfStudentActionPerformed
        if (subjectPageTypeOfStudent.getSelectedItem().equals("Regular")) {
            if (subjectPageYearLevel.getSelectedItem().equals("First Year")) {
                if (subjectPageSemester.getSelectedItem().equals("First Semester")) {
                    subjectPageSubject1.addItem("Introduction to Computing");
                    subjectPageSubject2.addItem("Computer Programming 1");
                    subjectPageSubject3.addItem("");
                    subjectPageSubject4.addItem("");

                } else if (subjectPageSemester.getSelectedItem().equals("Second Semester")) {
                    subjectPageSubject1.addItem("Computer Programming 2 ");
                    subjectPageSubject2.addItem("Multimedia");
                    subjectPageSubject3.addItem("Fundamentals of Computer Networking ");
                    subjectPageSubject4.addItem("");
                }
            } else if (subjectPageYearLevel.getSelectedItem().equals("Second Year")) {
                if (subjectPageSemester.getSelectedItem().equals("First Semester")) {
                    subjectPageSubject1.addItem("Data Structure");
                    subjectPageSubject2.addItem("Database Management Systems 1");
                    subjectPageSubject3.addItem("Python Programming");
                } else if (subjectPageSemester.getSelectedItem().equals("Second Semester")) {
                    subjectPageSubject1.addItem("System Analysis and Design");
                    subjectPageSubject2.addItem("Information Assurance and Security 1");
                    subjectPageSubject3.addItem("Object Oriented Programming");
                    subjectPageSubject4.addItem("Web Development");
                }
            } else if (subjectPageYearLevel.getSelectedItem().equals("Third Year")) {
                if (subjectPageSemester.getSelectedItem().equals("First Semester")) {
                    subjectPageSubject1.addItem("Computer Networking 2");
                    subjectPageSubject2.addItem("Information Assurance and Security 2");
                    subjectPageSubject3.addItem("Mobile Development");
                    subjectPageSubject4.addItem("Fundamentals of Data Mining");
                } else if (subjectPageSemester.getSelectedItem().equals("Second Semester")) {
                    subjectPageSubject1.addItem("IT Elective 2");
                    subjectPageSubject2.addItem("Capstone Project 1");
                    subjectPageSubject3.addItem("Advanced Web Development");
                    subjectPageSubject4.addItem("Advanced Data Mining");
                }
            } else if (subjectPageYearLevel.getSelectedItem().equals("Fourth Year")) {
                if (subjectPageSemester.getSelectedItem().equals("First Semester")) {
                    subjectPageSubject1.addItem("Advanced Mobile Development");
                    subjectPageSubject2.addItem("R Language");
                    subjectPageSubject3.addItem("Capstone Project 2");
                    subjectPageSubject4.addItem("");
                } else if (subjectPageSemester.getSelectedItem().equals("Second Semester")) {
                    subjectPageSubject1.addItem("");
                    subjectPageSubject2.addItem("");
                    subjectPageSubject3.addItem("");
                    subjectPageSubject4.addItem("");

                }
            }
        } else if (subjectPageTypeOfStudent.getSelectedItem().equals("Irregular")) {
            if (subjectPageYearLevel.getSelectedItem().equals("First Year")) {
                if (subjectPageSemester.getSelectedItem().equals("First Semester")) {
                    subjectPageSubject1.addItem("");
                    subjectPageSubject1.addItem("Introduction to Computing");
                    subjectPageSubject1.addItem("Computer Programming 1");
                    subjectPageSubject1.addItem("Database Management Systems");
                    subjectPageSubject1.addItem("Data Structure");
                    subjectPageSubject1.addItem("");

                    subjectPageSubject2.addItem("");
                    subjectPageSubject2.addItem("Introduction to Computing");
                    subjectPageSubject2.addItem("Computer Programming 1");
                    subjectPageSubject2.addItem("Database Management Systems");
                    subjectPageSubject2.addItem("Data Structure");
                    subjectPageSubject2.addItem("");

                    subjectPageSubject3.addItem("");
                    subjectPageSubject3.addItem("Introduction to Computing");
                    subjectPageSubject3.addItem("Computer Programming 1");
                    subjectPageSubject3.addItem("Database Management Systems");
                    subjectPageSubject3.addItem("Data Structure");
                    subjectPageSubject3.addItem("");

                    subjectPageSubject4.addItem("");
                    subjectPageSubject4.addItem("Introduction to Computing");
                    subjectPageSubject4.addItem("Computer Programming 1");
                    subjectPageSubject4.addItem("Database Management Systems");
                    subjectPageSubject4.addItem("Data Structure");
                    subjectPageSubject4.addItem("");

                } else if (subjectPageSemester.getSelectedItem().equals("Second Semester")) {
                    subjectPageSubject1.addItem("");
                    subjectPageSubject1.addItem("Computer Programming 2");
                    subjectPageSubject1.addItem("Multimedia");
                    subjectPageSubject1.addItem("Fundamentals of Computer Networking");
                    subjectPageSubject1.addItem("Python Programming");
                    subjectPageSubject1.addItem("");

                    subjectPageSubject2.addItem("");
                    subjectPageSubject2.addItem("Multimedia");
                    subjectPageSubject2.addItem("Fundamentals of Computer Networking");
                    subjectPageSubject2.addItem("Python Programming");
                    subjectPageSubject2.addItem("System Analysis and Design");
                    subjectPageSubject2.addItem("");

                    subjectPageSubject3.addItem("");
                    subjectPageSubject3.addItem("Fundamentals of Computer Networking");
                    subjectPageSubject3.addItem("Python Programming");
                    subjectPageSubject3.addItem("System Analysis and Design");
                    subjectPageSubject3.addItem("Information Assurance and Security 1");
                    subjectPageSubject3.addItem("");

                    subjectPageSubject4.addItem("");
                    subjectPageSubject4.addItem("Python Programming");
                    subjectPageSubject4.addItem("System Analysis and Design");
                    subjectPageSubject4.addItem("Information Assurance and Security 2");
                    subjectPageSubject4.addItem("Object Oriented Programming");
                    subjectPageSubject4.addItem("");
                }
            } else if (subjectPageYearLevel.getSelectedItem().equals("Second Year")) {
                if (subjectPageSemester.getSelectedItem().equals("First Semester")) {
                    subjectPageSubject1.addItem("");
                    subjectPageSubject1.addItem("Introduction to Computing");
                    subjectPageSubject1.addItem("Computer Programming 1");
                    subjectPageSubject1.addItem("Database Management Systems");
                    subjectPageSubject1.addItem("Data Structure");
                    subjectPageSubject1.addItem("");

                    subjectPageSubject2.addItem("");
                    subjectPageSubject2.addItem("Computer Programming 1");
                    subjectPageSubject2.addItem("Database Management Systems");
                    subjectPageSubject2.addItem("Data Structure");
                    subjectPageSubject2.addItem("Computer Networking 2");
                    subjectPageSubject2.addItem("");

                    subjectPageSubject3.addItem("");
                    subjectPageSubject3.addItem("Database Management Systems");
                    subjectPageSubject3.addItem("Data Structure");
                    subjectPageSubject3.addItem("Computer Networking 2");
                    subjectPageSubject3.addItem("Information Assurance and Security 1");
                    subjectPageSubject3.addItem("");

                    subjectPageSubject4.addItem("");
                    subjectPageSubject4.addItem("Data Structure");
                    subjectPageSubject4.addItem("Computer Networking 2");
                    subjectPageSubject4.addItem("Information Assurance and Security 2");
                    subjectPageSubject4.addItem("Fundamental of Data Mining");
                    subjectPageSubject4.addItem("");

                } else if (subjectPageSemester.getSelectedItem().equals("Second Semester")) {
                    subjectPageSubject1.addItem("");
                    subjectPageSubject1.addItem("Computer Programming 2");
                    subjectPageSubject1.addItem("Multimedia");
                    subjectPageSubject1.addItem("Fundamentals of Computer Networking");
                    subjectPageSubject1.addItem("Python Programming");
                    subjectPageSubject1.addItem("");

                    subjectPageSubject2.addItem("");
                    subjectPageSubject2.addItem("Multimedia");
                    subjectPageSubject2.addItem("Fundamentals of Computer Networking");
                    subjectPageSubject2.addItem("Python Programming");
                    subjectPageSubject2.addItem("System Analysis and Design");
                    subjectPageSubject2.addItem("");

                    subjectPageSubject3.addItem("");
                    subjectPageSubject3.addItem("Fundamentals of Computer Networking");
                    subjectPageSubject3.addItem("Python Programming");
                    subjectPageSubject3.addItem("System Analysis and Design");
                    subjectPageSubject3.addItem("Information Assurance and Security 1");
                    subjectPageSubject3.addItem("");

                    subjectPageSubject4.addItem("");
                    subjectPageSubject4.addItem("Python Programming");
                    subjectPageSubject4.addItem("System Analysis and Design");
                    subjectPageSubject4.addItem("Information Assurance and Security 2");
                    subjectPageSubject4.addItem("Object Oriented Programming");
                    subjectPageSubject4.addItem("");
                }
            } else if (subjectPageYearLevel.getSelectedItem().equals("Third Year")) {
                if (subjectPageSemester.getSelectedItem().equals("First Semester")) {
                    subjectPageSubject1.addItem("");
                    subjectPageSubject1.addItem("Introduction to Computing");
                    subjectPageSubject1.addItem("Computer Programming 1");
                    subjectPageSubject1.addItem("Database Management Systems");
                    subjectPageSubject1.addItem("Data Structure");
                    subjectPageSubject1.addItem("Computer Networking 2");
                    subjectPageSubject1.addItem("");

                    subjectPageSubject2.addItem("");
                    subjectPageSubject2.addItem("Computer Programming 1");
                    subjectPageSubject2.addItem("Database Management Systems");
                    subjectPageSubject2.addItem("Data Structure");
                    subjectPageSubject2.addItem("Computer Networking 2");
                    subjectPageSubject2.addItem("Fundamentals of Data Mining");
                    subjectPageSubject2.addItem("");

                    subjectPageSubject3.addItem("");
                    subjectPageSubject3.addItem("Database Management Systems");
                    subjectPageSubject3.addItem("Data Structure");
                    subjectPageSubject3.addItem("Computer Networking 2");
                    subjectPageSubject3.addItem("Information Assurance and Security 1");
                    subjectPageSubject3.addItem("Data Analysis using Python");
                    subjectPageSubject3.addItem("");

                    subjectPageSubject4.addItem("");
                    subjectPageSubject4.addItem("Data Structure");
                    subjectPageSubject4.addItem("Computer Networking 2");
                    subjectPageSubject4.addItem("Information Assurance and Security 2");
                    subjectPageSubject4.addItem("Fundamental of Data Mining");
                    subjectPageSubject4.addItem("Mobile Development");
                    subjectPageSubject4.addItem("");

                } else if (subjectPageSemester.getSelectedItem().equals("Second Semester")) {
                    subjectPageSubject1.addItem("");
                    subjectPageSubject1.addItem("Multimedia");
                    subjectPageSubject1.addItem("Fundamentals of Computer Networking");
                    subjectPageSubject1.addItem("Python Programming");
                    subjectPageSubject1.addItem("IT Elective 2");
                    subjectPageSubject1.addItem("Computer Programming 2");
                    subjectPageSubject1.addItem("");

                    subjectPageSubject2.addItem("");
                    subjectPageSubject2.addItem("Fundamentals of Computer Networking");
                    subjectPageSubject2.addItem("Capstone Project 1");
                    subjectPageSubject2.addItem("Python Programming");
                    subjectPageSubject2.addItem("System Analysis and Design");
                    subjectPageSubject2.addItem("Web Development");
                    subjectPageSubject2.addItem("");

                    subjectPageSubject3.addItem("");
                    subjectPageSubject3.addItem("Fundamentals of Computer Networking");
                    subjectPageSubject3.addItem("Python Programming");
                    subjectPageSubject3.addItem("System Analysis and Design");
                    subjectPageSubject3.addItem("Information Assurance and Security 1");
                    subjectPageSubject3.addItem("Advanced Data Mining");
                    subjectPageSubject3.addItem("IT Elective 3");
                    subjectPageSubject3.addItem("");

                    subjectPageSubject4.addItem("");
                    subjectPageSubject4.addItem("Python Programming");
                    subjectPageSubject4.addItem("System Analysis and Design");
                    subjectPageSubject4.addItem("Information Assurance and Security 2");
                    subjectPageSubject4.addItem("Object Oriented Programming");
                    subjectPageSubject4.addItem("IT Elective 2");
                    subjectPageSubject4.addItem("");
                }
            } else if (subjectPageYearLevel.getSelectedItem().equals("Fourth Year")) {
                if (subjectPageSemester.getSelectedItem().equals("First Semester")) {
                    subjectPageSubject1.addItem("");
                    subjectPageSubject1.addItem("Introduction to Computing");
                    subjectPageSubject1.addItem("Computer Programming 1");
                    subjectPageSubject1.addItem("Database Management Systems");
                    subjectPageSubject1.addItem("Data Structure");
                    subjectPageSubject1.addItem("Computer Networking 2");
                    subjectPageSubject1.addItem("R Language");
                    subjectPageSubject1.addItem("");

                    subjectPageSubject2.addItem("");
                    subjectPageSubject2.addItem("Computer Programming 1");
                    subjectPageSubject2.addItem("Database Management Systems");
                    subjectPageSubject2.addItem("Data Structure");
                    subjectPageSubject2.addItem("Computer Networking 2");
                    subjectPageSubject2.addItem("Fundamentals of Data Mining");
                    subjectPageSubject2.addItem("Capstone Project 2");
                    subjectPageSubject2.addItem("");

                    subjectPageSubject3.addItem("");
                    subjectPageSubject3.addItem("Database Management Systems");
                    subjectPageSubject3.addItem("Data Structure");
                    subjectPageSubject3.addItem("Computer Networking 2");
                    subjectPageSubject3.addItem("Information Assurance and Security 1");
                    subjectPageSubject3.addItem("Data Analysis using Python");
                    subjectPageSubject3.addItem("");

                    subjectPageSubject4.addItem("");
                    subjectPageSubject4.addItem("Data Structure");
                    subjectPageSubject4.addItem("Computer Networking 2");
                    subjectPageSubject4.addItem("Information Assurance and Security 2");
                    subjectPageSubject4.addItem("Fundamental of Data Mining");
                    subjectPageSubject4.addItem("Mobile Development");
                    subjectPageSubject4.addItem("");

                } else if (subjectPageSemester.getSelectedItem().equals("Second Semester")) {
                    subjectPageSubject1.addItem("");
                    subjectPageSubject1.addItem("Data Structure");
                    subjectPageSubject2.addItem("");
                    subjectPageSubject2.addItem("Computer Networking 2");
                    subjectPageSubject3.addItem("");
                    subjectPageSubject3.addItem("Fundamental of Data Mining");
                    subjectPageSubject4.addItem("");
                    subjectPageSubject4.addItem("Mobile Development");
                }
            }
        }


    }//GEN-LAST:event_subjectPageTypeOfStudentActionPerformed

    private void classPageSearchbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_classPageSearchbtnActionPerformed
        classpage.getSearchBtn();
    }//GEN-LAST:event_classPageSearchbtnActionPerformed

    private void classPageSaveBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_classPageSaveBtnActionPerformed
        if (isClassPageFieldEmpty()) {
            int id = classpage.getMax();
            String studentNumber = classPageStudentNumber.getText();
            String studentName = classPageStudentName.getText();
            String subject = classPageSubject.getSelectedItem().toString();
            String section = classPageSection.getSelectedItem().toString();
            String startTime = classPageStartTime.getSelectedItem().toString();
            String endTime = classPageEndTime.getSelectedItem().toString();
            String days = classPageDays.getText();
            String room = classPageRoom.getText();
            classpage.insert(id, studentNumber, studentName, subject, section, startTime, endTime, days, room);
            classPageTable.setModel(new DefaultTableModel(null, new Object[]{"ID", "Student Number", "Student Name",
                "Subject", "Section", "Start Time", "End Time", "Days", "Room"}));
            classpage.getClassDatabase(classPageTable, "");
            classPageClearField();
        }
    }//GEN-LAST:event_classPageSaveBtnActionPerformed

    private void classPageEditBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_classPageEditBtnActionPerformed
        if (isClassPageFieldEmpty()) {
            int id = Integer.parseInt(classPageID.getText());
            String studentNumber = classPageStudentNumber.getText();
            String studentName = classPageStudentName.getText();
            String subject = classPageSubject.getSelectedItem().toString();
            String section = classPageSection.getSelectedItem().toString();
            String startTime = classPageStartTime.getSelectedItem().toString();
            String endTime = classPageEndTime.getSelectedItem().toString();
            String days = classPageDays.getText();
            String room = classPageRoom.getText();
            classpage.update(id, studentNumber, studentName, subject, section, startTime, endTime, days, room);
            classPageTable.setModel(new DefaultTableModel(null, new Object[]{"ID", "Student Number", "Student Name",
                "Subject", "Section", "Start Time", "End Time", "Days", "Room"}));
            classpage.getClassDatabase(classPageTable, "");
            classPageClearField();
        } else {
            JOptionPane.showMessageDialog(this, "Student number doesn't exist");
        }
    }//GEN-LAST:event_classPageEditBtnActionPerformed

    private void classPageClearBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_classPageClearBtnActionPerformed
        classPageClearField();
    }//GEN-LAST:event_classPageClearBtnActionPerformed

    private void classPageDeleteBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_classPageDeleteBtnActionPerformed
        int id = Integer.parseInt(classPageID.getText());
        if (classpage.isClassIdExist(id)) {
            classpage.delete(id);
            classPageTable.setModel(new DefaultTableModel(null, new Object[]{"ID", "Student Number", "Student Name", "Subject", "Section", "Start Time",
                "End Time", "Days", "Room"}));
            classpage.getClassDatabase(classPageTable, "");
            classPageClearField();
        } else {
            JOptionPane.showMessageDialog(this, "Sorry, Student number doesn't exists");
        }
    }//GEN-LAST:event_classPageDeleteBtnActionPerformed

    private void classPageSectionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_classPageSectionActionPerformed


    }//GEN-LAST:event_classPageSectionActionPerformed

    private void classPageSubjectActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_classPageSubjectActionPerformed
        if (classPageSubject.getSelectedItem().equals("Fundamental of Computer Networking") || classPageSubject.getSelectedItem().equals("Introduction to Computing")
                || classPageSubject.getSelectedItem().equals("Computer Programming 1") || classPageSubject.getSelectedItem().equals("Multimedia")
                || classPageSubject.getSelectedItem().equals("Computer Programming 2")) {
            classPageSection.removeItem("BSIT 1.1");
            classPageSection.removeItem("BSIT 1.2");
            classPageSection.addItem("BSIT 1.1");
            classPageSection.addItem("BSIT 1.2");
            classPageSection.removeItem("BSIT 2.1");
            classPageSection.removeItem("BSIT 2.2");
            classPageSection.removeItem("BSIT 3.1");
            classPageSection.removeItem("BSIT 3.2");
            classPageSection.removeItem("BSIT 4.1");
            classPageSection.removeItem("BSIT 4.2");

        } else if (classPageSubject.getSelectedItem().equals("Data Structure") || classPageSubject.getSelectedItem().equals("Database Management Systems")
                || classPageSubject.getSelectedItem().equals("Python Programming") || classPageSubject.getSelectedItem().equals("System Analysis and Design")
                || classPageSubject.getSelectedItem().equals("Information Assurance and Security 1") || classPageSubject.getSelectedItem().equals("Object Oriented Programming")
                || classPageSubject.getSelectedItem().equals("Web Development")) {
            classPageSection.removeItem("BSIT 2.1");
            classPageSection.removeItem("BSIT 2.2");
            classPageSection.addItem("BSIT 2.1");
            classPageSection.addItem("BSIT 2.2");
            classPageSection.removeItem("BSIT 1.1");
            classPageSection.removeItem("BSIT 1.2");
            classPageSection.removeItem("BSIT 3.1");
            classPageSection.removeItem("BSIT 3.2");
            classPageSection.removeItem("BSIT 4.1");
            classPageSection.removeItem("BSIT 4.2");

        } else if (classPageSubject.getSelectedItem().equals("Computer Networking 2") || classPageSubject.getSelectedItem().equals("Information Assurance and Security 2")
                || classPageSubject.getSelectedItem().equals("Data Analysis using Python") || classPageSubject.getSelectedItem().equals("Mobile Development")
                || classPageSubject.getSelectedItem().equals("Fundamental of Data Mining") || classPageSubject.getSelectedItem().equals("IT Elective 2")
                || classPageSubject.getSelectedItem().equals("Capstone Project 1") || classPageSubject.getSelectedItem().equals("Advanced Mobile Development")
                || classPageSubject.getSelectedItem().equals("Advanced Web Development") || classPageSubject.getSelectedItem().equals("Advanced Data Mining")) {
            classPageSection.removeItem("BSIT 3.1");
            classPageSection.removeItem("BSIT 3.2");
            classPageSection.addItem("BSIT 3.1");
            classPageSection.addItem("BSIT 3.2");
            classPageSection.removeItem("BSIT 2.1");
            classPageSection.removeItem("BSIT 2.2");
            classPageSection.removeItem("BSIT 1.1");
            classPageSection.removeItem("BSIT 1.2");
            classPageSection.removeItem("BSIT 4.1");
            classPageSection.removeItem("BSIT 4.2");

        } else if (classPageSubject.getSelectedItem().equals("R Language") || classPageSubject.getSelectedItem().equals("Capstone Project 2")) {
            classPageSection.removeItem("BSIT 4.1");
            classPageSection.removeItem("BSIT 4.2");
            classPageSection.addItem("BSIT 4.1");
            classPageSection.addItem("BSIT 4.2");
            classPageSection.removeItem("BSIT 2.1");
            classPageSection.removeItem("BSIT 2.2");
            classPageSection.removeItem("BSIT 1.1");
            classPageSection.removeItem("BSIT 1.2");
            classPageSection.removeItem("BSIT 3.1");
            classPageSection.removeItem("BSIT 3.2");
        }
    }//GEN-LAST:event_classPageSubjectActionPerformed

    private void classPageSubjectMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_classPageSubjectMouseClicked

    }//GEN-LAST:event_classPageSubjectMouseClicked

    private void classPageSubjectMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_classPageSubjectMousePressed

    }//GEN-LAST:event_classPageSubjectMousePressed

    private void classPageSubjectMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_classPageSubjectMouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_classPageSubjectMouseReleased

    private void classPageTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_classPageTableMouseClicked
        model = (DefaultTableModel) classPageTable.getModel();
        rowIndex = classPageTable.getSelectedRow();
        classPageID.setText(model.getValueAt(rowIndex, 0).toString());
        classPageStudentNumber.setText(model.getValueAt(rowIndex, 1).toString());
        classPageStudentName.setText(model.getValueAt(rowIndex, 2).toString());
        String subject = model.getValueAt(rowIndex, 3).toString();
        classPageSubject.setSelectedItem(subject);
        String section = model.getValueAt(rowIndex, 4).toString();
        classPageSection.setSelectedItem(section);
        String startTime = model.getValueAt(rowIndex, 5).toString();
        classPageStartTime.setSelectedItem(startTime);
        String endTime = model.getValueAt(rowIndex, 6).toString();
        classPageEndTime.setSelectedItem(endTime);
        classPageDays.setText(model.getValueAt(rowIndex, 7).toString());
        classPageRoom.setText(model.getValueAt(rowIndex, 8).toString());

    }//GEN-LAST:event_classPageTableMouseClicked

    private void viewAttendancePageSearchFieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_viewAttendancePageSearchFieldKeyReleased
        String query = viewAttendancePageSearchField.getText().toLowerCase();
        viewAttendance.filterAttendance(query);
    }//GEN-LAST:event_viewAttendancePageSearchFieldKeyReleased

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        // TODO add your handling code here:
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        JFrame frame = new JFrame("Log out");
        if (JOptionPane.showConfirmDialog(frame, "Are you sure you want to Log out?", "Log out", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_NO_OPTION) {
            System.exit(0);
            

        }


    }//GEN-LAST:event_jButton7ActionPerformed

    private void viewAttendancePageTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_viewAttendancePageTableMouseClicked

        // TODO add your handling code here:
    }//GEN-LAST:event_viewAttendancePageTableMouseClicked

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton6ActionPerformed
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AdminPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AdminPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AdminPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AdminPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AdminPage().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel ClassPanel;
    private javax.swing.JPanel SubjectPanel;
    private javax.swing.JPanel attendancePanel;
    private javax.swing.JButton classPageClearBtn;
    public static javax.swing.JTextField classPageDays;
    private javax.swing.JButton classPageDeleteBtn;
    private javax.swing.JButton classPageEditBtn;
    public static javax.swing.JComboBox<String> classPageEndTime;
    public static javax.swing.JTextField classPageID;
    public static javax.swing.JTextField classPageRoom;
    private javax.swing.JButton classPageSaveBtn;
    public static javax.swing.JTextField classPageSearchField;
    private javax.swing.JButton classPageSearchbtn;
    public static javax.swing.JComboBox<String> classPageSection;
    public static javax.swing.JComboBox<String> classPageStartTime;
    public static javax.swing.JTextField classPageStudentName;
    public static javax.swing.JTextField classPageStudentNumber;
    public static javax.swing.JComboBox<String> classPageSubject;
    private javax.swing.JTable classPageTable;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JLabel labelNTCLogo;
    private javax.swing.JTextField professorPageAccountID;
    private javax.swing.JButton professorPageClearBtn;
    private javax.swing.JButton professorPageDeleteBtn;
    private javax.swing.JButton professorPageEditBtn;
    private javax.swing.JTextField professorPageEmail;
    private javax.swing.JTextField professorPageFirstName;
    private javax.swing.JTextField professorPageID;
    private javax.swing.JTextField professorPageLastName;
    private javax.swing.JPasswordField professorPagePassword;
    private javax.swing.JTextField professorPagePhone;
    private javax.swing.JButton professorPageSaveBtn;
    private javax.swing.JTable professorPageTable;
    private javax.swing.JComboBox<String> professorPageUserType;
    private javax.swing.JPanel professorPanel;
    private javax.swing.JButton studentPageClearBtn;
    private javax.swing.JButton studentPageDeleteBtn;
    private javax.swing.JButton studentPageEditBtn;
    private javax.swing.JTextField studentPageEmail;
    private javax.swing.JTextField studentPageFirstName;
    private javax.swing.JComboBox<String> studentPageGender;
    private javax.swing.JTextField studentPageID;
    private javax.swing.JTextField studentPageLastName;
    private javax.swing.JPasswordField studentPagePassword;
    private javax.swing.JTextField studentPagePhone;
    private javax.swing.JButton studentPageSaveBtn;
    private javax.swing.JTextField studentPageStudentNumber;
    private javax.swing.JTable studentPageTable;
    private javax.swing.JComboBox<String> studentPageUserType;
    private javax.swing.JPanel studentPanel;
    private javax.swing.JButton subjectPageClearBtn;
    private javax.swing.JButton subjectPageDeleteBtn;
    private javax.swing.JButton subjectPageEditBtn;
    private javax.swing.JTextField subjectPageID;
    private javax.swing.JButton subjectPageSaveBtn;
    private javax.swing.JButton subjectPageSearchBtn;
    public static javax.swing.JTextField subjectPageSearchField;
    private javax.swing.JComboBox<String> subjectPageSemester;
    public static javax.swing.JTextField subjectPageStudentName;
    public static javax.swing.JTextField subjectPageStudentNumber;
    private javax.swing.JComboBox<String> subjectPageSubject1;
    private javax.swing.JComboBox<String> subjectPageSubject2;
    private javax.swing.JComboBox<String> subjectPageSubject3;
    private javax.swing.JComboBox<String> subjectPageSubject4;
    private javax.swing.JTable subjectPageTable;
    private javax.swing.JComboBox<String> subjectPageTypeOfStudent;
    private javax.swing.JComboBox<String> subjectPageYearLevel;
    private javax.swing.JPanel subjectPanel;
    private javax.swing.JTextField viewAttendancePageSearchField;
    public static javax.swing.JTable viewAttendancePageTable;
    // End of variables declaration//GEN-END:variables
}
